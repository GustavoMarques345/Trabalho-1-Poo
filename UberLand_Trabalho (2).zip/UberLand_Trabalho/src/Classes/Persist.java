package Classes;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.imageio.stream.FileCacheImageInputStream;

public class Persist { // Classe para persistência de dados
	
	public static boolean gravar(Object a, String arquivo) {
		try {
			FileOutputStream arquivoGrav = new FileOutputStream(arquivo); // Abre o arquivo para a escrita
			
			ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGrav); //Trasforma objeto em Bytes
			
			objGravar.writeObject(a); //Escreve no arquivo
			objGravar.flush(); //Força a escrita e garante que foi salvo
			objGravar.close();
			arquivoGrav.close();
			
			return true;
			
		}catch(Exception e) {
			System.out.println("Erro ao Gravar" + e.getMessage());
			return false;
		}
		
	}
	
	//Método para carregar um objeto dos arquivos
	public static Object recuperar(String arquivo) {
		Object obj = null;
		FileInputStream arquivoLeitura = null;
		ObjectInputStream objLeitura = null;
		
		try {
			arquivoLeitura = new FileInputStream(arquivo); //Abre arquivo para leitura
			objLeitura = new ObjectInputStream (arquivoLeitura); //Transforma Bytes em objetos
			obj = objLeitura.readObject(); //Le o objeto
			objLeitura.close();
			arquivoLeitura.close();
			
		}catch(Exception e) {
			System.out.println("Erro ao recuperar" + e.getMessage());
			return null;
		}
		
		
		return obj;
	}
	
	

}
