package Classes;

import java.io.Serializable;
import java.util.ArrayList;

public class Motorista extends Usuario implements Serializable{
	
	private String endereco;
	private String cnh;
	private String nome_Social;
	private ArrayList<Veiculo> veiculos; // Necessário pois cada motorista pode ter mais de um veiculo cadastrado
	private boolean ativo; //Método para ativar um motorista
	private String status; 

	public Motorista (String n, String cp, String data, String end, String c, String social, String st) {
		super(n, cp, data);
		this.endereco = end;
		this.cnh = c;
		this.nome_Social = social;
		this.status = st;
		this.veiculos = new ArrayList<>();
	}

	
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}	
	
	public String getEndereco() {
		return endereco;
	}

	public void setCnh(String cnh) {
		this.cnh = cnh;
	}

	public String getCnh() {
		return cnh;
	}

	public void setNome_Social(String nome_Social) {
		this.nome_Social = nome_Social;
	}


	public String getNome_Social() {
		return nome_Social;
	}
	
	
	
	
	//Métodos
	
	
	public void addVeiculo(Veiculo veiculo) { // Método para adicionar um veiculo à lista de motoristas
		if (!veiculos.contains(veiculo)) {
			veiculos.add(veiculo);
		}
	}
	
	public void removeVeiculo(Veiculo veiculo) { //Método para remover os veículos
		veiculos.remove(veiculo);
	}
	
	public ArrayList<Veiculo> getVeiculos() { //Retorna uma lista de veículos
		return veiculos;
	}
	
	public boolean temVeiculo() { // Verifica se o motorista tem veículo
		return !veiculos.isEmpty();
	}
	
	public int getQuantidadeVeiculos() { //Retorna a quatidade de veículos
		return veiculos.size();
	}
	
	
	public void ativarMotorista() {
		this.ativo = true;
	}
	
	public void desativarMotorista() {
		this.ativo = false;
		for (Veiculo v : veiculos) {
			v.desativar();  // Desativa todos os veículos
		}
	}
	
	public void removeVeiculo(String placa) {
	    veiculos.removeIf(v -> v.getPlaca().equals(placa));
	}
	
	public void setStatus() {
		this.status = "Disponivel";
		for (Veiculo v : veiculos) {
			v.disponivel();
		}
	}	
	
	public String getStatus() {
		return status;
	}

	
	public void emViagem() {
		this.status = "Em viagem";
		for (Veiculo v : veiculos) {
			v.emViagem();
		}
	}
	
	public void naoDisp() {
		this.status = "Nao disponivel";
		for (Veiculo v : veiculos) {
			v.naoDisponivel();
		}
	}
	
	public void finalizando() {
		this.status = "Finalizando viagem";
		for (Veiculo v : veiculos) {
			v.finalizandoViagem();
		}
	}
}