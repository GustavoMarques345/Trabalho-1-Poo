package Classes;

import java.util.ArrayList;

public class DadosCorrida {
	
	private ArrayList<Corrida> corridas;
	private static final String ARQUIVO = "corridas.dat";
	
	public DadosCorrida() {
		Object obj = Persist.recuperar(ARQUIVO);
		if(obj != null) {
		corridas = (ArrayList<Corrida>) obj; // Carrega do arquivo
		}else {
			corridas = new ArrayList<>();
		}
	}
	
	public void cadastrar(Corrida c) {
		corridas.add(c);
		Persist.gravar(corridas, ARQUIVO);
	}
	
	public void atualizar(Corrida corridaAtualizada) {   // Método necessário para atualizar as corridas e evitar a duplicação dos dados 
	    for (int i = 0; i < corridas.size(); i++) {
	        Corrida c = corridas.get(i);
	        if (c.getCliente() != null && corridaAtualizada.getCliente() != null &&
	            c.getCliente().getCpf().equals(corridaAtualizada.getCliente().getCpf()) &&
	            c.getDataCorrida().equals(corridaAtualizada.getDataCorrida()) &&
	            c.getHoraCorrida().equals(corridaAtualizada.getHoraCorrida())) {
	            
	            corridas.set(i, corridaAtualizada);  
	            Persist.gravar(corridas, ARQUIVO);
	            return;
	        }
	    }
	}
	
	public ArrayList<Corrida> listar(){
		return corridas;
	}
	
	
	//Método para mostrar as corridas feitas pelos clientes
	public ArrayList<Corrida> buscarCliente(String cpf){
		ArrayList<Corrida> resultado = new ArrayList<>(); //Nova lista
		for(Corrida c : corridas) { //Percorre as corridas e verifica o cliente
			if(c.getCliente() != null && c.getCliente().getCpf().equals(cpf)) {
				resultado.add(c);
			}
		}
		
		return resultado;
	}

}
