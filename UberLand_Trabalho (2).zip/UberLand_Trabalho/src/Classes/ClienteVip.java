package Classes;

import java.io.Serializable;

public class ClienteVip extends Cliente implements Serializable {
	
	private double desconto; // Atributo que recebe o desconto do cliente Vip.
	
	public ClienteVip(Cliente cli, double desc) {
		super(cli.getNome(), cli.getCpf());
		this.desconto = desc;
	}


	public void setDesconto(double desconto) {
		this.desconto = desconto;
	}
	
	public double getDesconto() {
		return desconto;
	}
	

}
