package Classes;

import java.io.*;
import java.util.ArrayList;

public class DadosCliente {
	
	private ArrayList<Cliente> clientes;
	private static final String ARQUIVO = "clientes.dat"; //Nome do arquivo
	
	public DadosCliente() {
		Object obj = Persist.recuperar(ARQUIVO); //Carrega o arquivo
		if(obj != null) {
		clientes = (ArrayList <Cliente>) obj;
		}else {
			clientes = new ArrayList<>();
		}
	}
	
	//Cadastrar Clientes
	public void cadastrar(Cliente c) {
		clientes.add(c);
	    Persist.gravar(clientes, ARQUIVO);
	}
	
	public void atualizar(Cliente clienteAtualizado) {  //Atualiza os dados do cliente toda vez que ele for avaliado por um motorista
	    for (int i = 0; i < clientes.size(); i++) {
	        if (clientes.get(i).getCpf().equals(clienteAtualizado.getCpf())) {
	            clientes.set(i, clienteAtualizado);
	            Persist.gravar(clientes, ARQUIVO);
	            return;
	        }
	    }
	}
	
	
	public Cliente buscar (String cpf) {
		for(Cliente c: clientes) {
			if(c.getCpf().equals(cpf)) {
				return c;
			}
		}
		return null;
	}
	
	public boolean excluir(String cpf) {
		Cliente c = buscar(cpf);
		if(c != null) {
			clientes.remove(c);
			Persist.gravar(clientes, ARQUIVO); // Atualiza a lista no arquivo
			return true;
		}
		return false;
	}
	
	//Listar 
	public ArrayList<Cliente> listar(){
		return clientes;
	}
	
	public int TotalClientes() {
		return clientes.size();
	}
		
}
