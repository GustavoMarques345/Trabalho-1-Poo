package Classes;

public class SistemaUberLand {
	
	//A ideia para criar essa classe é para garantir que todas as telas usem a mesma lista de dados
	
	private static SistemaUberLand instancia; // Usado para guardar uma única instância
	
	//Atributos de instancias
	private DadosCliente dadosCli;
	private DadosMotorista dadosMot;
	private DadosVeiculo dadosVei;
	private DadosCorrida dadosCor;
	
	private SistemaUberLand() {
		
		dadosCli = new DadosCliente();
		dadosMot = new DadosMotorista();
		dadosVei = new DadosVeiculo();
		dadosCor = new DadosCorrida();
		
	}
	
	//Método que retorna a única isntância do problema. Ele cira um novo objeto e reutiliza o existente
	
	public static SistemaUberLand getInstance() {
        if (instancia == null) {
            instancia = new SistemaUberLand();
        }
        return instancia;
    }
	
	public DadosCliente getDadosUsuarios() {
		return dadosCli; 
		}
	
    public DadosMotorista getDadosMotoristas() {
    	return dadosMot;
    	}
    
    
    public DadosVeiculo getDadosVeiculos() {
    	return dadosVei;
    	}
    
    public DadosCorrida getDadosCorridas() {
    	return dadosCor;
    	
    }
	

}
