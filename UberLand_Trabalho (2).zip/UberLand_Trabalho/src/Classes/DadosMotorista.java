package Classes;

import java.util.ArrayList;

public class DadosMotorista {
	private ArrayList<Motorista> motoristas;
	private static final String ARQUIVO = "motoristas.dat";
	
	public DadosMotorista() {
		Object obj = Persist.recuperar(ARQUIVO);
		if(obj != null) {
		motoristas = ( ArrayList<Motorista>) obj;
		}else {
			motoristas = new ArrayList<>();
		}
	}
	
	public void cadastrar(Motorista m) {
		motoristas.add(m);
		Persist.gravar(motoristas, ARQUIVO);
	}
	
	public Motorista buscar(String cpf) {
		for(Motorista m : motoristas) {
			if(m.getCpf().equals(cpf)) {
				return m;
			}
		}
		return null;
	}
	
	public boolean excluir (String cpf) {
		Motorista m = buscar(cpf);
		if(m != null) {
			motoristas.remove(m);
			Persist.gravar(motoristas, ARQUIVO);
			return true;
		}
		return false;
	}
	
	public void atualizar(Motorista motoristaAtualizado) { //Atualiza os dados do motorista, necessário para evitar a duplicação de cadastro caso o mesmo motorista queira cadastrar mais de um veículo
	    for (int i = 0; i < motoristas.size(); i++) {
	        if (motoristas.get(i).getCpf().equals(motoristaAtualizado.getCpf())) {
	            motoristas.set(i, motoristaAtualizado);  
	            Persist.gravar(motoristas, ARQUIVO);      // Salva no arquivo
	            return;
	        }
	    }
	}
	
	public ArrayList<Motorista> listar(){
		return motoristas;
	}
	

}
