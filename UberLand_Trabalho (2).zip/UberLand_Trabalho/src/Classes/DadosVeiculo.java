package Classes;

import java.util.ArrayList;

public class DadosVeiculo {
	
	private ArrayList<Veiculo> veiculos;
	private static final String ARQUIVO = "veiculos.dat";
	
	public DadosVeiculo() {
		Object obj = Persist.recuperar(ARQUIVO);
		if(obj != null) {
		veiculos = ( ArrayList<Veiculo>) obj;
		}else {
			veiculos = new ArrayList<>();
		}
	}
	
	public void cadastrar (Veiculo v) {
		veiculos.add(v);
		Persist.gravar(veiculos, ARQUIVO);
	}
	
	public Veiculo buscar(String placa) {
		for(Veiculo v : veiculos) {
			if(v.getPlaca().equals(placa)) {
				return v;
			}
		}
		return null;
	}
	
	public boolean excluir(String placa) {
		Veiculo v = buscar(placa);
		if(v != null) {
			veiculos.remove(v);
			Persist.gravar(veiculos, ARQUIVO);
			return true;
		}
		return false;
	}
	
	public ArrayList<Veiculo> listar(){
		return veiculos;
	}

}
