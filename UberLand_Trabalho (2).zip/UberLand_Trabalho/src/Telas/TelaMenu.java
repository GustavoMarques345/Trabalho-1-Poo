package Telas;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class TelaMenu extends JFrame {

    private static final long serialVersionUID = 1L;
    
    // Cores
    private final Color COR_PRIMARIA = new Color(0, 90, 180);
    private final Color COR_TEXTO = new Color(60, 60, 60);
    
    // Cores para cada seção
    private final Color COR_CLIENTE = new Color(52, 152, 219);    // Azul
    private final Color COR_MOTORISTA = new Color(155, 89, 182);  // Roxo
    private final Color COR_ADMIN = new Color(231, 76, 60);       // Vermelho
    
    public TelaMenu() {
        setTitle("UberLand - Menu Principal");
        setSize(500, 700); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel fundo = new JPanel(new GridBagLayout());
        fundo.setBackground(new Color(248, 249, 250));
        setContentPane(fundo);

        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setLayout(new GridBagLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(25, 25, 25, 25)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.insets = new Insets(5, 0, 5, 0);

        // CABEÇALHO
        JLabel titulo = new JLabel("UberLand", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titulo.setForeground(COR_PRIMARIA);
        gbc.gridx = 0;
        gbc.gridy = 0;
        card.add(titulo, gbc);
        
        JLabel subtitulo = new JLabel("Escolha seu perfil", SwingConstants.CENTER);
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitulo.setForeground(new Color(120, 120, 120));
        gbc.gridy = 1;
        card.add(subtitulo, gbc);
        
        // SEÇÃO CLIENTE
        JLabel lblCliente = new JLabel("👤 ÁREA DO CLIENTE");
        lblCliente.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblCliente.setForeground(COR_CLIENTE);
        gbc.gridy = 2;
        gbc.insets = new Insets(20, 0, 10, 0);
        card.add(lblCliente, gbc);
        
        JButton btnCadastrarCliente = criarBotaoMenu(
            "📝 Cadastrar novo cliente",
            "Criar nova conta",
            COR_CLIENTE,
            e -> abrirTelaCadastroCliente()
        );
        gbc.gridy = 3;
        gbc.insets = new Insets(0, 0, 5, 0);
        card.add(btnCadastrarCliente, gbc);
        
        JButton btnLoginCliente = criarBotaoMenu(
            "🔑 Fazer login como cliente",
            "Entrar com CPF",
            COR_CLIENTE,
            e -> abrirTelaLoginCliente()
        );
        gbc.gridy = 4;
        card.add(btnLoginCliente, gbc);
        
        // SEÇÃO MOTORISTA
        JLabel lblMotorista = new JLabel("🚗 ÁREA DO MOTORISTA");
        lblMotorista.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblMotorista.setForeground(COR_MOTORISTA);
        gbc.gridy = 5;
        gbc.insets = new Insets(25, 0, 10, 0);
        card.add(lblMotorista, gbc);
        
        JButton btnCadastrarMotorista = criarBotaoMenu(
            "📝 Cadastrar novo motorista",
            "Criar nova conta",
            COR_MOTORISTA,
            e -> abrirTelaCadastroMotorista()
        );
        gbc.gridy = 6;
        gbc.insets = new Insets(0, 0, 5, 0);
        card.add(btnCadastrarMotorista, gbc);
        
        JButton btnLoginMotorista = criarBotaoMenu(
            "🔑 Fazer login como motorista",
            "Entrar com CPF",
            COR_MOTORISTA,
            e -> abrirTelaLoginMotorista()
        );
        gbc.gridy = 7;
        card.add(btnLoginMotorista, gbc);
        
        // SEÇÃO ADMINISTRAR
        JLabel lblAdmin = new JLabel("⚙️ GERENCIAMENTO");
        lblAdmin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblAdmin.setForeground(COR_ADMIN);
        gbc.gridy = 8;
        gbc.insets = new Insets(25, 0, 10, 0);
        card.add(lblAdmin, gbc);
        
        // Gerenciar Clientes
        JButton btnGerenciarClientes = criarBotaoMenu(
            "👥 Gerenciar Clientes",
            "Buscar, visualizar ou remover clientes",
            COR_ADMIN,
            e -> new TelaBuscarRemoverCliente().setVisible(true)
        );
        gbc.gridy = 9;
        gbc.insets = new Insets(0, 0, 5, 0);
        card.add(btnGerenciarClientes, gbc);
        
        // Gerenciar Motoristas
        JButton btnGerenciarMotoristas = criarBotaoMenu(
            "🚗 Gerenciar Motoristas",
            "Buscar, visualizar ou remover motoristas",
            COR_ADMIN,
            e -> new TelaBuscarRemoverMotorista().setVisible(true) 
        );
        gbc.gridy = 10;
        gbc.insets = new Insets(0, 0, 5, 0);
        card.add(btnGerenciarMotoristas, gbc);
        
        // Gerenciar Veículos
        JButton btnGerenciarVeiculos = criarBotaoMenu(
            "🚘 Gerenciar Veículos",
            "Buscar, visualizar ou remover veículos",
            COR_ADMIN,
            e -> new TelaBuscarRemoverVeiculo().setVisible(true) 
        );
        gbc.gridy = 11;
        gbc.insets = new Insets(0, 0, 5, 0);
        card.add(btnGerenciarVeiculos, gbc);
        
        // Gerenciar Corridas 
        JButton btnGerenciarCorridas = criarBotaoMenu(
            "🏁 Gerenciar Corridas",
            "Visualizar histórico de corridas",
            COR_ADMIN,
            e -> new TelaBuscarRemoverCorrida().setVisible(true) 
        );
        gbc.gridy = 12;
        card.add(btnGerenciarCorridas, gbc);
        
        // BOTÃO VOLTAR
        JButton btnVoltar = new JButton("← Voltar à tela inicial");
        btnVoltar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btnVoltar.setBackground(new Color(200, 200, 200));
        btnVoltar.setForeground(Color.BLACK);
        btnVoltar.setFocusPainted(false);
        btnVoltar.setBorderPainted(false);
        btnVoltar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnVoltar.setBorder(BorderFactory.createEmptyBorder(12, 25, 12, 25));
        
        btnVoltar.addActionListener(e -> {
            new TelaInicial().setVisible(true);
            dispose();
        });
        
        btnVoltar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnVoltar.setBackground(new Color(180, 180, 180));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnVoltar.setBackground(new Color(200, 200, 200));
            }
        });
        
        gbc.gridy = 13;
        gbc.insets = new Insets(25, 0, 5, 0);
        card.add(btnVoltar, gbc);

        // Adicionar card ao fundo
        GridBagConstraints gbcFundo = new GridBagConstraints();
        gbcFundo.gridx = 0;
        gbcFundo.gridy = 0;
        gbcFundo.insets = new Insets(20, 20, 20, 20);
        fundo.add(card, gbcFundo);
    }
    
    private JButton criarBotaoMenu(String texto, String tooltip, Color cor, ActionListener acao) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        botao.setForeground(cor);
        botao.setBackground(Color.WHITE);
        botao.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            BorderFactory.createEmptyBorder(12, 20, 12, 20)
        ));
        botao.setFocusPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setToolTipText(tooltip);
        botao.setHorizontalAlignment(SwingConstants.LEFT);
        botao.addActionListener(acao);
        
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(new Color(245, 245, 245));
                botao.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(cor, 1),
                    BorderFactory.createEmptyBorder(12, 20, 12, 20)
                ));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(Color.WHITE);
                botao.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
                    BorderFactory.createEmptyBorder(12, 20, 12, 20)
                ));
            }
        });
        
        return botao;
    }
    
    // MÉTODOS
    private void abrirTelaCadastroCliente() {
        new TelaCadastroCliente().setVisible(true);
        dispose();
    }
    
    private void abrirTelaLoginCliente() {
        new TelaLogin().setVisible(true);
    }
    
    private void abrirTelaCadastroMotorista() {
        new TelaCadastroMotorista().setVisible(true);
        dispose();
    }
    
    private void abrirTelaLoginMotorista() {
        new TelaLogin().setVisible(true);
    }
}