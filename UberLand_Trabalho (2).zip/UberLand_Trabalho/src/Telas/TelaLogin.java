package Telas;

import Classes.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class TelaLogin extends JFrame { // Reutilizei essa tela para fazer o login de clientes e motoristas no sistema 
    
    private JTextField txtCpf;
    private JComboBox<String> cbTipo;
    private JButton btnEntrar, btnCancelar;
    private SistemaUberLand sistema;
    
    // Cores refinadas
    private final Color COR_PRIMARIA = new Color(0, 90, 180);
    private final Color COR_SECUNDARIA = new Color(0, 140, 255);
    private final Color COR_FUNDO = new Color(245, 245, 250);
    private final Color COR_TEXTO = new Color(60, 60, 60);
    private final Color COR_BORDA = new Color(220, 220, 220);
    
    public TelaLogin() {
        this.sistema = SistemaUberLand.getInstance();
        
        setTitle("UberLand - Acessar Conta");
        setSize(400, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        setUndecorated(true);
        
        // Painel principal 
        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
               
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                
                
                g2.setColor(new Color(0, 0, 0, 10));
                g2.fillRoundRect(2, 2, getWidth()-4, getHeight()-4, 18, 18);
                
                g2.dispose();
                super.paintComponent(g);
            }
        };
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setOpaque(false);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setContentPane(mainPanel);
        
        //CABEÇALHO 
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Ícone decorativo
        JLabel lblIcon = new JLabel("🔐", SwingConstants.CENTER);
        lblIcon.setFont(new Font("Segoe UI", Font.PLAIN, 48));
        lblIcon.setForeground(COR_PRIMARIA);
        
        JLabel lblTitle = new JLabel("Bem-vindo de volta!", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(COR_TEXTO);
        
        JLabel lblSubtitle = new JLabel("Faça login para continuar", SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSubtitle.setForeground(new Color(150, 150, 150));
        
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);
        titlePanel.add(lblTitle);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(lblSubtitle);
        
        headerPanel.add(lblIcon, BorderLayout.NORTH);
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        
        // PAINEL DO FORMULÁRIO 
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 10, 8, 10);
        
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel lblTipo = new JLabel("Selecione seu perfil:");
        lblTipo.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTipo.setForeground(COR_TEXTO);
        formPanel.add(lblTipo, gbc);
        
        // ComboBox Tipo
        gbc.gridy = 1;
        String[] tipos = {"👤 Cliente", "🚗 Motorista"};
        cbTipo = new JComboBox<>(tipos);
        cbTipo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cbTipo.setBackground(Color.WHITE);
        cbTipo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        ((JLabel)cbTipo.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        formPanel.add(cbTipo, gbc);
        
        // Label CPF
        gbc.gridy = 2;
        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblCpf.setForeground(COR_TEXTO);
        formPanel.add(lblCpf, gbc);
        
        // Campo CPF
        gbc.gridy = 3;
        txtCpf = new JTextField(15);
        txtCpf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtCpf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        formPanel.add(txtCpf, gbc);
        
       
        gbc.gridy = 4;
        JLabel dica = new JLabel("Digite apenas números ou com pontuação", SwingConstants.CENTER);
        dica.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        dica.setForeground(new Color(150, 150, 150));
        formPanel.add(dica, gbc);
        
        //PAINEL DE BOTÕES
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        // Botão Cancelar
        btnCancelar = criarBotaoSecundario("Cancelar");
        btnCancelar.addActionListener(e -> dispose());
        
        // Botão Entrar 
        btnEntrar = criarBotaoPrincipal("Entrar");
        btnEntrar.addActionListener(e -> fazerLogin());
        
        buttonPanel.add(btnCancelar);
        buttonPanel.add(btnEntrar);
        
        // Atalho Enter
        txtCpf.addActionListener(e -> fazerLogin());
        
        
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.add(headerPanel, BorderLayout.NORTH);
        contentPanel.add(formPanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Permitir arrastar a janela 
        addMouseMotionListener(new MouseAdapter() {
            int x, y;
            @Override
            public void mousePressed(MouseEvent e) {
                x = e.getX();
                y = e.getY();
            }
            @Override
            public void mouseDragged(MouseEvent e) {
                setLocation(getX() + e.getX() - x, getY() + e.getY() - y);
            }
        });
    }
    
    private JButton criarBotaoPrincipal(String texto) {
        JButton botao = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getModel().isPressed()) {
                    g2.setColor(COR_PRIMARIA.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(COR_SECUNDARIA);
                } else {
                    g2.setColor(COR_PRIMARIA);
                }
                
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                
                super.paintComponent(g);
            }
        };
        
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
        botao.setForeground(Color.WHITE);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setContentAreaFilled(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        
        return botao;
    }
    
    private JButton criarBotaoSecundario(String texto) {
        JButton botao = new JButton(texto) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getModel().isPressed()) {
                    g2.setColor(new Color(200, 200, 200));
                } else if (getModel().isRollover()) {
                    g2.setColor(new Color(230, 230, 230));
                } else {
                    g2.setColor(Color.WHITE);
                }
                
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(COR_BORDA);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 10, 10);
                g2.dispose();
                
                super.paintComponent(g);
            }
        };
        
        botao.setFont(new Font("Segoe UI", Font.BOLD, 14));
        botao.setForeground(COR_TEXTO);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setContentAreaFilled(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        
        return botao;
    }
    
    private void fazerLogin() {
        String cpf = txtCpf.getText().trim();
        String tipo = (String) cbTipo.getSelectedItem();
        
        // Validar CPF
        if (cpf.isEmpty()) {
            mostrarErro("Digite o CPF!", "Campo Obrigatório");
            txtCpf.requestFocus();
            return;
        }
        
       
        String cpfLimpo = cpf.replaceAll("[^0-9]", ""); 
        
        if (!Usuario.validar(cpfLimpo)) {
            mostrarErro("CPF inválido! Verifique.", "CPF Inválido");
            txtCpf.requestFocus();
            return;
        }
        
        if (tipo.equals("👤 Cliente")) {
            Cliente cliente = sistema.getDadosUsuarios().buscar(cpfLimpo);
           
             if (cliente != null) {
                JOptionPane.showMessageDialog(this,
                    "✅ Bem-vindo, " + cliente.getNome() + "!\n" +
                    "Corridas realizadas: " + cliente.getNroCorrida(),
                    "Login realizado",
                    JOptionPane.INFORMATION_MESSAGE);
                
                new TelaCliente(cliente).setVisible(true);
                dispose();
                
                for (Window w : Window.getWindows()) {
                    if (w instanceof TelaMenu) {
                        w.dispose();
                        break;
                    }
                }
            } else {
                mostrarErro("Cliente não encontrado com este CPF!", "Erro");
            }
            
        } else { // Motorista
            Motorista motorista = sistema.getDadosMotoristas().buscar(cpfLimpo);
            
            if (motorista != null) {
                JOptionPane.showMessageDialog(this,
                    "✅ Bem-vindo, " + motorista.getNome() + "!\n" +
                    "Status: " + motorista.getStatus(),
                    "Login realizado",
                    JOptionPane.INFORMATION_MESSAGE);
                
                new TelaMotorista(motorista).setVisible(true);
                dispose();
                
                for (Window w : Window.getWindows()) {
                    if (w instanceof TelaMenu) {
                        w.dispose();
                        break;
                    }
                }
            } else {
                mostrarErro("Motorista não encontrado com este CPF!", "Erro");
            }
        }
    }
    
    private void mostrarErro(String mensagem, String titulo) {
        JOptionPane.showMessageDialog(this, 
            mensagem, 
            titulo, 
            JOptionPane.ERROR_MESSAGE);
    }
}