package Telas;

import Classes.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TelaBuscarRemoverVeiculo extends JFrame {

    private static final long serialVersionUID = 1L;
    
    // Cores 
    private final Color COR_PRIMARIA = new Color(241, 196, 15);     
    private final Color COR_FUNDO = new Color(255, 250, 240);      
    private final Color COR_CARD = Color.WHITE;                    
    private final Color COR_TEXTO = new Color(60, 60, 60);         
    private final Color COR_BORDA = new Color(220, 220, 220);      
    private final Color COR_SUCESSO = new Color(46, 204, 113);     
    private final Color COR_INFO = new Color(52, 152, 219);        
    
    // Componentes
    private JTable tabelaVeiculos;
    private JTextField txtBusca;
    private DefaultTableModel modeloTabela;
    private JLabel lblTotalVeiculos;
    
    // Sistema
    private SistemaUberLand sistema = SistemaUberLand.getInstance();
    
    public TelaBuscarRemoverVeiculo() {
        setTitle("UberLand - Gerenciar Veículos");
        setSize(850, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Painel principal
        JPanel fundo = new JPanel(new BorderLayout());
        fundo.setBackground(COR_FUNDO);
        setContentPane(fundo);
        
        // Card principal
        JPanel card = new JPanel();
        card.setBackground(COR_CARD);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // Cabeçalho
        card.add(criarCabecalho(), BorderLayout.NORTH);
        
        // Painel central
        JPanel painelCentral = new JPanel(new BorderLayout(10, 10));
        painelCentral.setOpaque(false);
        painelCentral.add(criarPainelBusca(), BorderLayout.NORTH);
        painelCentral.add(criarPainelTabela(), BorderLayout.CENTER);
        
        card.add(painelCentral, BorderLayout.CENTER);
        
        fundo.add(card, BorderLayout.CENTER);
        
        // Carregar todos os veículos ao abrir
        carregarTodosVeiculos();
    }
    
    private JPanel criarCabecalho() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setAlignmentX(Component.CENTER_ALIGNMENT);
        cabecalho.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JLabel lblIcone = new JLabel("🚘");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 48));
        lblIcone.setForeground(COR_PRIMARIA);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblTitulo = new JLabel("Gerenciar Veículos");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(COR_TEXTO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lblTotalVeiculos = new JLabel("Carregando...");
        lblTotalVeiculos.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTotalVeiculos.setForeground(new Color(120, 120, 120));
        lblTotalVeiculos.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblTitulo);
        cabecalho.add(Box.createVerticalStrut(2));
        cabecalho.add(lblTotalVeiculos);
        
        return cabecalho;
    }
    
    private JPanel criarPainelBusca() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        painel.setOpaque(false);
        painel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        
        JLabel lblBusca = new JLabel("Buscar por Placa:");
        lblBusca.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblBusca.setForeground(COR_TEXTO);
        
        txtBusca = new JTextField(15);
        txtBusca.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusca.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        txtBusca.setPreferredSize(new Dimension(200, 40));
        txtBusca.addActionListener(e -> buscarVeiculoPorPlaca());
        
        JButton btnBuscar = new JButton("🔍 Buscar");
        btnBuscar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setBackground(COR_INFO);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorderPainted(false);
        btnBuscar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBuscar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnBuscar.addActionListener(e -> buscarVeiculoPorPlaca());
        
        JButton btnLimpar = new JButton("🗑️ Limpar");
        btnLimpar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnLimpar.setForeground(Color.WHITE);
        btnLimpar.setBackground(new Color(108, 117, 125));
        btnLimpar.setFocusPainted(false);
        btnLimpar.setBorderPainted(false);
        btnLimpar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLimpar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnLimpar.addActionListener(e -> {
            txtBusca.setText("");
            txtBusca.requestFocus();
            carregarTodosVeiculos();
        });
        
        
        btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO);
            }
        });
        
        btnLimpar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125).darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125));
            }
        });
        
        painel.add(lblBusca);
        painel.add(txtBusca);
        painel.add(btnBuscar);
        painel.add(btnLimpar);
        
        return painel;
    }
    
    private JPanel criarPainelTabela() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setOpaque(false);
        
        // Modelo da tabela 
        String[] colunas = {"ID", "Placa", "Marca", "Cor", "Passageiros", "Categoria", "Status", "Motorista"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Criar tabela
        tabelaVeiculos = new JTable(modeloTabela);
        tabelaVeiculos.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelaVeiculos.setRowHeight(35);
        tabelaVeiculos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabelaVeiculos.setShowGrid(true);
        tabelaVeiculos.setGridColor(new Color(230, 230, 230));
        tabelaVeiculos.setSelectionBackground(new Color(230, 240, 255));
        
        // Cabeçalho da tabela
        JTableHeader header = tabelaVeiculos.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(240, 240, 240));
        header.setForeground(COR_TEXTO);
        header.setReorderingAllowed(false);
        
        // Centralizar colunas
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        for (int i = 0; i < colunas.length; i++) {
            if (i != 1 && i != 2) {
                tabelaVeiculos.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }
        
        // Larguras das colunas
        tabelaVeiculos.getColumnModel().getColumn(0).setPreferredWidth(40);   // ID
        tabelaVeiculos.getColumnModel().getColumn(1).setPreferredWidth(100);  // Placa
        tabelaVeiculos.getColumnModel().getColumn(2).setPreferredWidth(150);  // Marca
        tabelaVeiculos.getColumnModel().getColumn(3).setPreferredWidth(80);   // Cor
        tabelaVeiculos.getColumnModel().getColumn(4).setPreferredWidth(80);   // Passageiros
        tabelaVeiculos.getColumnModel().getColumn(5).setPreferredWidth(100);  // Categoria
        tabelaVeiculos.getColumnModel().getColumn(6).setPreferredWidth(100);  // Status
        tabelaVeiculos.getColumnModel().getColumn(7).setPreferredWidth(150);  // Motorista
        
        JScrollPane scrollPane = new JScrollPane(tabelaVeiculos);
        scrollPane.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
        scrollPane.setPreferredSize(new Dimension(780, 300));
        
        painel.add(scrollPane, BorderLayout.CENTER);
        
        // Painel de botões 
        JPanel painelAcoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        painelAcoes.setOpaque(false);
        painelAcoes.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            " Ações ",
            TitledBorder.CENTER,
            TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            COR_TEXTO
        ));
        
        JButton btnRemover = criarBotaoAcao("🗑️ Remover Veículo", COR_PRIMARIA, 180);
        btnRemover.addActionListener(e -> removerVeiculo());
        
        JButton btnAtualizar = criarBotaoAcao("🔄 Atualizar Lista", COR_SUCESSO, 180);
        btnAtualizar.addActionListener(e -> carregarTodosVeiculos());
        
        JButton btnVoltar = criarBotaoAcao("← Voltar ao Menu", new Color(150, 150, 150), 180);
        btnVoltar.addActionListener(e -> dispose());
        
        painelAcoes.add(btnRemover);
        painelAcoes.add(btnAtualizar);
        painelAcoes.add(btnVoltar);
        
        painel.add(painelAcoes, BorderLayout.SOUTH);
        
        return painel;
    }
    
    private JButton criarBotaoAcao(String texto, Color cor, int largura) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        botao.setPreferredSize(new Dimension(largura, 40));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
   // Buscar Veiculo por Placa
    private void buscarVeiculoPorPlaca() {
        String placaDigitada = txtBusca.getText().trim().toUpperCase();
        
        if (placaDigitada.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Digite a placa do veículo.",
                "Campo Vazio",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Veiculo veiculo = sistema.getDadosVeiculos().buscar(placaDigitada);
        
        if (veiculo != null) {
            mostrarDetalhesVeiculo(veiculo);
        } else {
            JOptionPane.showMessageDialog(this,
                "Nenhum veículo encontrado com a placa: " + placaDigitada,
                "Não encontrado",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    //Mostra Detalhes dos veículos, como marca, nome, motorista ...
    private void mostrarDetalhesVeiculo(Veiculo v) {
        // Determinar categoria
        String categoria = "";
        if (v instanceof UberX) categoria = "UberX";
        else if (v instanceof UberComfort) categoria = "UberComfort";
        else if (v instanceof UberBlack) categoria = "UberBlack";
        
        // Buscar motorista associado (percorrendo a lista de veículos de cada motorista)
        String motoristaNome = "Nenhum";
        for (Motorista m : sistema.getDadosMotoristas().listar()) {
            for (Veiculo veic : m.getVeiculos()) {
                if (veic.getPlaca().equals(v.getPlaca())) {
                    motoristaNome = m.getNome();
                    break;
                }
            }
            if (!motoristaNome.equals("Nenhum")) break;
        }
        
        // Características específicas por categoria
        String caracteristicas = "";
        if (v instanceof UberX) {
            UberX u = (UberX) v;
            caracteristicas = "• Ar condicionado: " + (u.isPossuiAr() ? "✅ Sim" : "❌ Não") +
                              "<br>• Conforto básico: " + (u.isConfortoBasico() ? "✅ Sim" : "❌ Não");
        } else if (v instanceof UberComfort) {
            UberComfort u = (UberComfort) v;
            caracteristicas = "• Espaço extra: " + (u.isEspaçoExtra() ? "✅ Sim" : "❌ Não") +
                              "<br>• Banco reclinável: " + (u.isBancoReclinavel() ? "✅ Sim" : "❌ Não") +
                              "<br>• Ar dual zone: " + (u.isAr_dualzone() ? "✅ Sim" : "❌ Não");
        } else if (v instanceof UberBlack) {
            UberBlack u = (UberBlack) v;
            caracteristicas = "• Interior premium: " + (u.isInteriorPremium() ? "✅ Sim" : "❌ Não") +
                              "<br>• Rodas de liga leve: " + (u.isRodasligaleve() ? "✅ Sim" : "❌ Não") +
                              "<br>• Nº de malas: " + u.getNro_malas();
        }
        
        // CONCATENAÇÃO SIMPLES - SEM String.format()
        String mensagem = "<html><body style='width: 380px; padding: 10px; font-family: Segoe UI;'>" +
            "<h3 style='color: #f39c12; border-bottom: 2px solid #f39c12; padding-bottom: 5px;'>" +
            "🚘 DADOS DO VEÍCULO</h3>" +
            
            "<table style='width: 100%; border-collapse: collapse; font-size: 12px;'>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Placa:</b></td>" +
            "<td style='padding: 4px;'>" + v.getPlaca() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Categoria:</b></td>" +
            "<td style='padding: 4px;'>" + categoria + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Marca:</b></td>" +
            "<td style='padding: 4px;'>" + v.getMarca() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Cor:</b></td>" +
            "<td style='padding: 4px;'>" + v.getCor() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Chassi:</b></td>" +
            "<td style='padding: 4px;'>" + v.getChassi() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Passageiros:</b></td>" +
            "<td style='padding: 4px;'>" + v.getNro_passageiros() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Status:</b></td>" +
            "<td style='padding: 4px;'>" + v.getStatus() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Ativado:</b></td>" +
            "<td style='padding: 4px;'>" + (v.isAtivado() ? "✅ Sim" : "❌ Não") + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Motorista:</b></td>" +
            "<td style='padding: 4px;'>" + motoristaNome + "</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 8px; background: #f39c1220; border-top: 1px solid #f39c12; " +
            "border-bottom: 1px solid #f39c12; text-align: center; font-weight: bold;'>⚙️ CARACTERÍSTICAS</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 8px;'>" + caracteristicas + "</td></tr>" +
            
            "</table></body></html>";
        
        JOptionPane.showMessageDialog(this, 
            mensagem, 
            "Detalhes: " + v.getPlaca(), 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    //Carrega todos os veículos
    private void carregarTodosVeiculos() {
        limparTabela();
        
        ArrayList<Veiculo> veiculos = sistema.getDadosVeiculos().listar();
        
        int id = 1;
        for (Veiculo v : veiculos) {
            // Determinar categoria
            String categoria = "";
            if (v instanceof UberX) categoria = "UberX";
            else if (v instanceof UberComfort) categoria = "UberComfort";
            else if (v instanceof UberBlack) categoria = "UberBlack";
            
            // Buscar motorista associado (percorrendo a lista de veículos)
            String motoristaNome = "---";
            for (Motorista m : sistema.getDadosMotoristas().listar()) {
                for (Veiculo veic : m.getVeiculos()) {
                    if (veic.getPlaca().equals(v.getPlaca())) {
                        motoristaNome = m.getNome();
                        break;
                    }
                }
                if (!motoristaNome.equals("---")) break;
            }
            
            Object[] linha = {
                id++,
                v.getPlaca(),
                v.getMarca(),
                v.getCor(),
                v.getNro_passageiros(),
                categoria,
                v.getStatus(),
                motoristaNome
            };
            modeloTabela.addRow(linha);
        }
        
        lblTotalVeiculos.setText("Total de veículos cadastrados: " + veiculos.size());
    }
    private void limparTabela() {
        if (modeloTabela != null) {
            modeloTabela.setRowCount(0);
        }
    }
	
    //Remove Veiculo
    private void removerVeiculo() {
        int linha = tabelaVeiculos.getSelectedRow();
        
        if (linha == -1) {
            JOptionPane.showMessageDialog(this,
                "Selecione um veículo na tabela para remover.",
                "Nenhum selecionado",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String placa = (String) modeloTabela.getValueAt(linha, 1);
        String marca = (String) modeloTabela.getValueAt(linha, 2);
        
        // Verificar se veículo está associado a algum motorista
        boolean temMotorista = false;
        String nomeMotorista = "";
        Motorista motoristaDono = null;
        
        for (Motorista m : sistema.getDadosMotoristas().listar()) {
            for (Veiculo veic : m.getVeiculos()) {
                if (veic.getPlaca().equals(placa)) {
                    temMotorista = true;
                    nomeMotorista = m.getNome();
                    motoristaDono = m;
                    break;
                }
            }
            if (temMotorista) break;
        }
        
        if (temMotorista) {
            int confirm = JOptionPane.showConfirmDialog(this,
                "<html><body style='width: 400px; padding: 10px;'>" +
                "<h3 style='color: #e74c3c;'>⚠️ ATENÇÃO!</h3>" +
                "<p>Este veículo está associado ao motorista <b>" + nomeMotorista + "</b>.</p>" +
                "<p>Se removê-lo, o motorista ficará sem este veículo!</p>" +
                "<p>Deseja continuar mesmo assim?</p>" +
                "</body></html>",
                "Veículo associado",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
            
            // Remover veículo da lista do motorista
            if (motoristaDono != null) {
                motoristaDono.removeVeiculo(placa); 
                sistema.getDadosMotoristas().cadastrar(motoristaDono);
            }
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><body style='width: 350px; padding: 10px;'>" +
            "<h3 style='color: #f39c12;'>⚠️ CONFIRMAR REMOÇÃO</h3>" +
            "<p>Tem certeza que deseja remover o veículo?</p>" +
            "<p><b>Placa:</b> " + placa + "<br>" +
            "<b>Marca:</b> " + marca + "</p>" +
            "<p><font color='red'><b>Esta ação não pode ser desfeita!</b></font></p>" +
            "</body></html>",
            "Confirmar Remoção",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean removeu = sistema.getDadosVeiculos().excluir(placa);
            
            if (removeu) {
                JOptionPane.showMessageDialog(this,
                    "✅ Veículo removido com sucesso!",
                    "Remoção Concluída",
                    JOptionPane.INFORMATION_MESSAGE);
                
                carregarTodosVeiculos();
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Erro ao remover veículo!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
}
    