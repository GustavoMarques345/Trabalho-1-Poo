package Telas;

import Classes.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TelaBuscarRemoverCliente extends JFrame {

    private static final long serialVersionUID = 1L;
    
    // Cores
    private final Color COR_PRIMARIA = new Color(231, 76, 60);     
    private final Color COR_SECUNDARIA = new Color(241, 96, 80);   
    private final Color COR_FUNDO = new Color(250, 240, 240);      
    private final Color COR_CARD = Color.WHITE;                    
    private final Color COR_TEXTO = new Color(60, 60, 60);         
    private final Color COR_BORDA = new Color(220, 220, 220);      
    private final Color COR_SUCESSO = new Color(46, 204, 113);     
    private final Color COR_INFO = new Color(52, 152, 219);        
    
    // Componentes
    private JTable tabelaClientes;
    private JTextField txtBusca;
    private DefaultTableModel modeloTabela;
    private JLabel lblTotalClientes;
    
    // Sistema
    private SistemaUberLand sistema = SistemaUberLand.getInstance();
    
    public TelaBuscarRemoverCliente() {
        setTitle("UberLand - Gerenciar Clientes");
        setSize(800, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Painel principal
        JPanel fundo = new JPanel(new BorderLayout());
        fundo.setBackground(COR_FUNDO);
        setContentPane(fundo);
        
        // Card principal
        JPanel card = new JPanel();
        card.setBackground(COR_CARD);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // Cabeçalho
        card.add(criarCabecalho(), BorderLayout.NORTH);
        
        // Painel central
        JPanel painelCentral = new JPanel(new BorderLayout(10, 10));
        painelCentral.setOpaque(false);
        painelCentral.add(criarPainelBusca(), BorderLayout.NORTH);
        painelCentral.add(criarPainelTabela(), BorderLayout.CENTER);
        
        card.add(painelCentral, BorderLayout.CENTER);
        
        fundo.add(card, BorderLayout.CENTER);
        
        // Carregar todos os clientes ao abrir
        carregarTodosClientes();
    }
    
    private JPanel criarCabecalho() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setAlignmentX(Component.CENTER_ALIGNMENT);
        cabecalho.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JLabel lblIcone = new JLabel("👥");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 48));
        lblIcone.setForeground(COR_PRIMARIA);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblTitulo = new JLabel("Gerenciar Clientes");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(COR_TEXTO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lblTotalClientes = new JLabel("Carregando...");
        lblTotalClientes.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTotalClientes.setForeground(new Color(120, 120, 120));
        lblTotalClientes.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblTitulo);
        cabecalho.add(Box.createVerticalStrut(2));
        cabecalho.add(lblTotalClientes);
        
        return cabecalho;
    }
    
    private JPanel criarPainelBusca() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        painel.setOpaque(false);
        painel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        
        JLabel lblBusca = new JLabel("Buscar por CPF:");
        lblBusca.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblBusca.setForeground(COR_TEXTO);
        
        txtBusca = new JTextField(15);
        txtBusca.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusca.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        txtBusca.setPreferredSize(new Dimension(200, 40));
        txtBusca.addActionListener(e -> buscarClientePorCPF());
        
        JButton btnBuscar = new JButton("🔍 Buscar");
        btnBuscar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setBackground(COR_INFO);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorderPainted(false);
        btnBuscar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBuscar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnBuscar.addActionListener(e -> buscarClientePorCPF());
        
        JButton btnLimpar = new JButton("🗑️ Limpar");
        btnLimpar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnLimpar.setForeground(Color.WHITE);
        btnLimpar.setBackground(new Color(108, 117, 125));
        btnLimpar.setFocusPainted(false);
        btnLimpar.setBorderPainted(false);
        btnLimpar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLimpar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnLimpar.addActionListener(e -> {
            txtBusca.setText("");
            txtBusca.requestFocus();
            carregarTodosClientes();
        });
        
        // Efeitos hover
        btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO);
            }
        });
        
        btnLimpar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125).darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125));
            }
        });
        
        painel.add(lblBusca);
        painel.add(txtBusca);
        painel.add(btnBuscar);
        painel.add(btnLimpar);
        
        return painel;
    }
    
    private JPanel criarPainelTabela() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setOpaque(false);
        
        // Modelo da tabela
        String[] colunas = {"ID", "Nome", "CPF", "E-mail", "Celular", "Corridas", "Status"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Criar tabela
        tabelaClientes = new JTable(modeloTabela);
        tabelaClientes.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelaClientes.setRowHeight(35);
        tabelaClientes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabelaClientes.setShowGrid(true);
        tabelaClientes.setGridColor(new Color(230, 230, 230));
        tabelaClientes.setSelectionBackground(new Color(230, 240, 255));
        
        // Cabeçalho da tabela
        JTableHeader header = tabelaClientes.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(240, 240, 240));
        header.setForeground(COR_TEXTO);
        header.setReorderingAllowed(false);
        
        // Centralizar algumas colunas
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        tabelaClientes.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tabelaClientes.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        tabelaClientes.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
        tabelaClientes.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);
        
        // Larguras das colunas
        tabelaClientes.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabelaClientes.getColumnModel().getColumn(1).setPreferredWidth(180);
        tabelaClientes.getColumnModel().getColumn(2).setPreferredWidth(120);
        tabelaClientes.getColumnModel().getColumn(3).setPreferredWidth(220);
        tabelaClientes.getColumnModel().getColumn(4).setPreferredWidth(100);
        tabelaClientes.getColumnModel().getColumn(5).setPreferredWidth(70);
        tabelaClientes.getColumnModel().getColumn(6).setPreferredWidth(80);
        
        JScrollPane scrollPane = new JScrollPane(tabelaClientes);
        scrollPane.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
        scrollPane.setPreferredSize(new Dimension(730, 300));
        
        painel.add(scrollPane, BorderLayout.CENTER);
        
        // Painel de botões de ação
        JPanel painelAcoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        painelAcoes.setOpaque(false);
        painelAcoes.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            " Ações ",
            TitledBorder.CENTER,
            TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            COR_TEXTO
        ));
        
        JButton btnRemover = criarBotaoAcao("🗑️ Remover Cliente", COR_PRIMARIA, 180);
        btnRemover.addActionListener(e -> removerCliente());
        
        JButton btnAtualizar = criarBotaoAcao("🔄 Atualizar Lista", COR_SUCESSO, 180);
        btnAtualizar.addActionListener(e -> carregarTodosClientes());
        
        JButton btnVoltar = criarBotaoAcao("← Voltar ao Menu", new Color(150, 150, 150), 180);
        btnVoltar.addActionListener(e -> dispose());
        
        painelAcoes.add(btnRemover);
        painelAcoes.add(btnAtualizar);
        painelAcoes.add(btnVoltar);
        
        painel.add(painelAcoes, BorderLayout.SOUTH);
        
        return painel;
    }
    
    private JButton criarBotaoAcao(String texto, Color cor, int largura) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        botao.setPreferredSize(new Dimension(largura, 40));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private String formatarCPF(String cpf) {
        if (cpf == null || cpf.length() != 11) return cpf;
        return cpf.substring(0, 3) + "." + cpf.substring(3, 6) + "." + 
               cpf.substring(6, 9) + "-" + cpf.substring(9, 11);
    }
    
    private String formatarCelular(String celular) {
        if (celular == null || celular.length() < 10) return celular;
        if (celular.length() == 11) {
            return "(" + celular.substring(0, 2) + ") " + 
                   celular.substring(2, 7) + "-" + celular.substring(7);
        }
        return celular;
    }
    
    // Método para Buscar Clientes
    private void buscarClientePorCPF() {
        String cpfDigitado = txtBusca.getText().trim();
        
        // Validação: CPF não pode estar vazio
        if (cpfDigitado.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Digite o CPF do cliente.",
                "Campo Vazio",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Remove pontuação para buscar 
        String cpfLimpo = cpfDigitado.replaceAll("[^0-9]", "");
        
        // Valida se tem 11 dígitos
        if (cpfLimpo.length() != 11) {
            JOptionPane.showMessageDialog(this,
                "CPF deve ter 11 dígitos.",
                "CPF Inválido",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Busca o cliente no sistema, no ArrayList e no arquivo
        Cliente cliente = sistema.getDadosUsuarios().buscar(cpfLimpo);
        
        if (cliente != null) {
            // Cliente encontrado, então mostra todos os detalhes
            mostrarDetalhesCliente(cliente);
        } else {
            // Cliente não encontrado
            JOptionPane.showMessageDialog(this,
                "Nenhum cliente encontrado com o CPF: " + formatarCPF(cpfLimpo),
                "Cliente não encontrado",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void mostrarDetalhesCliente(Cliente c) {
    	
    	//Formata o CPF para a exibição
        String cpfFormatado = formatarCPF(c.getCpf());
        
        // Formata celular para exibição 
        String celularFormatado = formatarCelular(c.getNro_Celular());
        
        // Determina status VIP 
        String statusVIP = c.getNroCorrida() >= 50 ? "✅ VIP" : "❌ Cliente Comum";
        
        // Calcula desconto
        double desconto = c.calcularDesconto() * 100;
        
        // Cria mensagem HTML com formatação
        String mensagem = String.format(
            "<html><body style='width: 350px; padding: 10px; font-family: Segoe UI;'>" +
            "<h2 style='color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; text-align: center;'>" +
            "👤 DETALHES DO CLIENTE</h2>" +
            
            "<table style='width: 100%%; border-collapse: collapse; margin-top: 15px;'>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa; width: 40%%;'><b>📌 Nome:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>🆔 CPF:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>📧 E-mail:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>📱 Celular:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>🎂 Nascimento:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>⚥ Gênero:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>💳 Pagamento:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 15px; background: #e74c3c20; border-top: 2px solid #e74c3c; " +
            "border-bottom: 2px solid #e74c3c; text-align: center; font-weight: bold;'>📊 ESTATÍSTICAS</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>🏁 Corridas realizadas:</b></td>" +
            "<td style='padding: 10px; background: white;'>%d</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>⭐ Status:</b></td>" +
            "<td style='padding: 10px; background: white;'>%s</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>💰 Desconto atual:</b></td>" +
            "<td style='padding: 10px; background: white;'>%.1f%%</td></tr>" +
            
            "<tr><td style='padding: 10px; background: #f8f9fa;'><b>📈 Avaliação média:</b></td>" +
            "<td style='padding: 10px; background: white;'>%.1f ⭐</td></tr>" +
            
            "</table></body></html>",
            
            // Dados pessoais
            c.getNome(),
            cpfFormatado,
            c.getEmail(),
            celularFormatado,
            c.getDatanasc() != null ? c.getDatanasc() : "Não informado",
            c.getGenero(),
            c.getForma_Pagamento(),
            
            // Estatísticas
            c.getNroCorrida(),
            statusVIP,
            desconto,
            c.getMedia()
        );
        
        // Exibe a janela com os detalhes
        JOptionPane.showMessageDialog(this, 
            mensagem, 
            "Detalhes do Cliente - " + c.getNome(), 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void carregarTodosClientes() {
        limparTabela();
        
        ArrayList<Cliente> clientes = sistema.getDadosUsuarios().listar();
        
        int id = 1;
        for (Cliente c : clientes) {
            String status = c.getNroCorrida() >= 50 ? "VIP ⭐" : "Comum";
            String cpfFormatado = formatarCPF(c.getCpf());
            String celularFormatado = formatarCelular(c.getNro_Celular());
            
            Object[] linha = {
                id++,
                c.getNome(),
                cpfFormatado,
                c.getEmail(),
                celularFormatado,
                c.getNroCorrida(),
                status
            };
            modeloTabela.addRow(linha);
        }
        
        // Atualiza o label com o total de clientes
        lblTotalClientes.setText("Total de clientes cadastrados: " + clientes.size());
    }
    
    private void removerCliente() {
        int linha = tabelaClientes.getSelectedRow();
        
        if (linha == -1) {
            JOptionPane.showMessageDialog(this,
                "Selecione um cliente na tabela para remover.",
                "Nenhum selecionado",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        String cpfLinha = (String) modeloTabela.getValueAt(linha, 2);
        String cpfBusca = cpfLinha.replaceAll("[^0-9]", "");
        
        // Confirmação antes de remover
        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><body style='width: 350px; padding: 10px;'>" +
            "<h3 style='color: #e74c3c;'>⚠️ CONFIRMAR REMOÇÃO</h3>" +
            "<p>Tem certeza que deseja remover o cliente?</p>" +
            "<p><b>Nome:</b> " + nome + "<br>" +
            "<b>CPF:</b> " + cpfLinha + "</p>" +
            "<p><font color='red'><b>Esta ação não pode ser desfeita!</b></font></p>" +
            "</body></html>",
            "Confirmar Remoção",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            // Chama o método excluir do DadosCliente
            boolean removeu = sistema.getDadosUsuarios().excluir(cpfBusca);
            
            if (removeu) {
                JOptionPane.showMessageDialog(this,
                    "✅ Cliente removido com sucesso!",
                    "Remoção Concluída",
                    JOptionPane.INFORMATION_MESSAGE);
                
                carregarTodosClientes(); // Recarrega a tabela
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Erro ao remover cliente!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void limparTabela() {
        modeloTabela.setRowCount(0);
    }
}