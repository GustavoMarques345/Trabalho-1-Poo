package Telas;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class TelaInicial extends JFrame {

    private static final long serialVersionUID = 1L;
    
    private final Color COR_PRIMARIA = new Color(0, 90, 180);     // Azul Uber
    private final Color COR_SECUNDARIA = new Color(0, 140, 255);  // Azul claro
    private final Color COR_FUNDO = new Color(240, 245, 250);     // Fundo suave
    private final Color COR_CARD = Color.WHITE;                   // Card branco
    private final Color COR_TEXTO = new Color(60, 60, 60);        // Texto cinza escuro
    private final Color COR_TEXTO_CLARO = new Color(120, 120, 120); // Texto cinza
    
    public TelaInicial() {
        setTitle("UberLand - Sistema de Transporte");
        setSize(580, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        // Painel principal 
        JPanel fundo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                
                
                GradientPaint gp = new GradientPaint(
                    0, 0, COR_PRIMARIA,
                    getWidth(), getHeight(), COR_SECUNDARIA
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        fundo.setLayout(new GridBagLayout());
        setContentPane(fundo);

        
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
               
                g2d.setColor(new Color(0, 0, 0, 15));
                g2d.fillRoundRect(4, 4, getWidth()-4, getHeight()-4, 20, 20);
                
             
                g2d.setColor(COR_CARD);
                g2d.fillRoundRect(0, 0, getWidth()-4, getHeight()-4, 20, 20);
            }
        };
        card.setOpaque(false);
        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(440, 320));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ÍCONE DO APLICATIVO
        JLabel lblIcone = new JLabel("🚖", SwingConstants.CENTER);
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 52));
        lblIcone.setForeground(COR_PRIMARIA);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        card.add(lblIcone, gbc);

        // TÍTULO PRINCIPAL
        JLabel titulo = new JLabel("UberLand", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titulo.setForeground(COR_PRIMARIA);
        gbc.gridy = 1;
        gbc.insets = new Insets(5, 0, 5, 0);
        card.add(titulo, gbc);

        // SUBTÍTULO
        JLabel subtitulo = new JLabel("Sistema de Gerenciamento de Transporte", SwingConstants.CENTER);
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitulo.setForeground(COR_TEXTO_CLARO);
        gbc.gridy = 2;
        card.add(subtitulo, gbc);

        
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(230, 230, 230));
        sep.setPreferredSize(new Dimension(300, 1));
        gbc.gridy = 3;
        gbc.insets = new Insets(15, 40, 15, 40);
        card.add(sep, gbc);

        // TEXTO DESCRITIVO
        JLabel texto = new JLabel(
            "<html><center><font size='4'>✨</font><br><br>"
            + "<font size='3'>Gerencie clientes, motoristas,<br>"
            + "veículos e corridas de forma eficiente.</font></center></html>",
            SwingConstants.CENTER);
        texto.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        texto.setForeground(COR_TEXTO);
        gbc.gridy = 4;
        gbc.insets = new Insets(5, 40, 20, 40);
        card.add(texto, gbc);

        // BOTÃO ENTRAR
        JButton btnEntrar = new JButton("🚀 Entrar no Sistema") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
               
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                
                super.paintComponent(g2);
                g2.dispose();
            }
        };
        
        btnEntrar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setBackground(COR_PRIMARIA);
        btnEntrar.setBorderPainted(false);
        btnEntrar.setFocusPainted(false);
        btnEntrar.setContentAreaFilled(false);
        btnEntrar.setOpaque(false);
        btnEntrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnEntrar.setBorder(BorderFactory.createEmptyBorder(12, 40, 12, 40));
        btnEntrar.setPreferredSize(new Dimension(200, 45));
        
        
        btnEntrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnEntrar.setBackground(COR_SECUNDARIA);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                btnEntrar.setBackground(COR_PRIMARIA);
            }
        });

        // Ação do botão
        btnEntrar.addActionListener(e -> {
            new TelaMenu().setVisible(true);
            dispose();
        });

        gbc.gridy = 5;
        gbc.insets = new Insets(10, 0, 20, 0);
        card.add(btnEntrar, gbc);

        // RODAPÉ
        JLabel rodape = new JLabel("© 2024 UberLand - Versão 1.0", SwingConstants.CENTER);
        rodape.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        rodape.setForeground(new Color(150, 150, 150));
        gbc.gridy = 6;
        gbc.insets = new Insets(20, 0, 0, 0);
        card.add(rodape, gbc);

        // Adiciona card ao fundo
        GridBagConstraints gbcFundo = new GridBagConstraints();
        gbcFundo.gridx = 0;
        gbcFundo.gridy = 0;
        gbcFundo.insets = new Insets(20, 20, 20, 20);
        fundo.add(card, gbcFundo);
    }
}