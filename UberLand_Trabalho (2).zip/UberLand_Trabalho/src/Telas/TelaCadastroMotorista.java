package Telas;

import javax.swing.*;
import javax.swing.border.*;

import Classes.Motorista;
import Classes.SistemaUberLand;
import Classes.Usuario;

import java.awt.*;
import java.awt.event.*;

public class TelaCadastroMotorista extends JFrame {

    private static final long serialVersionUID = 1L;
    
    private final Color COR_PRIMARIA = new Color(155, 89, 182);     
    private final Color COR_SECUNDARIA = new Color(175, 109, 202);  
    private final Color COR_FUNDO = new Color(245, 240, 250);      
    private final Color COR_CARD = Color.WHITE;                     
    private final Color COR_TEXTO = new Color(60, 60, 60);        
    private final Color COR_BORDA = new Color(220, 220, 220);       
    
  
    private JTextField txtNome, txtCPF, txtNascimento, txtEndereco, txtCNH, txtNomeSocial;
    
    private SistemaUberLand sistema = SistemaUberLand.getInstance(); // Reeferência ao sistema
    
    public TelaCadastroMotorista() {
        setTitle("UberLand - Cadastro de Motorista");
        setSize(520, 550); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Painel principal 
        JPanel fundo = new JPanel(new BorderLayout());
        fundo.setBackground(COR_FUNDO);
        setContentPane(fundo);
        
        
        JPanel card = new JPanel();
        card.setBackground(COR_CARD);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // Cabeçalho
        card.add(criarCabecalho());
        card.add(Box.createVerticalStrut(10));
        
     
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(230, 230, 230));
        sep.setMaximumSize(new Dimension(450, 1));
        card.add(sep);
        card.add(Box.createVerticalStrut(15));
        
        
        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setOpaque(false);
        painelForm.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // NOME
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Nome:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtNome = criarTextField();
        painelForm.add(txtNome, gbc);
        
        // CPF
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("CPF:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtCPF = criarTextField();
        painelForm.add(txtCPF, gbc);
        
        // DATA NASCIMENTO
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Data Nasc.:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtNascimento = criarTextField();
        painelForm.add(txtNascimento, gbc);
        
        // ENDEREÇO
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Endereço:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtEndereco = criarTextField();
        painelForm.add(txtEndereco, gbc);
        
        // CNH
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Nº CNH:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtCNH = criarTextField();
        painelForm.add(txtCNH, gbc);
        
        // NOME SOCIAL
        gbc.gridx = 0; gbc.gridy = 5;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Nome Social:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtNomeSocial = criarTextField();
        painelForm.add(txtNomeSocial, gbc);
        
        card.add(painelForm);
        card.add(Box.createVerticalStrut(30));
        
        // Botões
        card.add(criarPainelBotoes());
        
        
        JScrollPane scrollPane = new JScrollPane(card);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        fundo.add(scrollPane, BorderLayout.CENTER);
    }
    
    private JPanel criarCabecalho() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Ícone
        JLabel lblIcone = new JLabel("🚗");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        lblIcone.setForeground(COR_PRIMARIA);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Título
        JLabel lblTitulo = new JLabel("Cadastro de Motorista");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(COR_TEXTO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Subtítulo
        JLabel lblSubtitulo = new JLabel("Informe os dados do motorista");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(120, 120, 120));
        lblSubtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblTitulo);
        cabecalho.add(Box.createVerticalStrut(2));
        cabecalho.add(lblSubtitulo);
        
        return cabecalho;
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        label.setForeground(COR_TEXTO);
        return label;
    }
    
    private JTextField criarTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        field.setPreferredSize(new Dimension(250, 35));
        field.setMaximumSize(new Dimension(250, 35));
        
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_SECUNDARIA, 2),
                    BorderFactory.createEmptyBorder(7, 9, 7, 9)
                ));
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_BORDA, 1),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
        });
        
        return field;
    }
    
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        painel.setOpaque(false);
        painel.setMaximumSize(new Dimension(400, 50));
        
        // Botão Cadastrar
        JButton btnCadastrar = criarBotao("💾 Cadastrar", COR_PRIMARIA);
        btnCadastrar.addActionListener(e -> cadastrarMotorista());
        
        // Botão Limpar
        JButton btnLimpar = criarBotao("🗑️ Limpar", new Color(108, 117, 125));
        btnLimpar.addActionListener(e -> limparFormulario());
        
        // Botão Voltar
        JButton btnVoltar = criarBotao("← Voltar", new Color(150, 150, 150));
        btnVoltar.addActionListener(e -> dispose());
        
        painel.add(btnCadastrar);
        painel.add(btnLimpar);
        painel.add(btnVoltar);
        
        return painel;
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void cadastrarMotorista() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, preencha o nome do motorista.", 
                "Campo Obrigatório", 
                JOptionPane.WARNING_MESSAGE);
            txtNome.requestFocus();
            return;
        }
        
        if (txtCNH.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, preencha o número da CNH.", 
                "Campo Obrigatório", 
                JOptionPane.WARNING_MESSAGE);
            txtCNH.requestFocus();
            return;
        }
        
        //Verificando se o CPF foi indicado
        String cpf = txtCPF.getText().trim();
        if(cpf.isEmpty()) {
        	JOptionPane.showMessageDialog(this, "Por favor, preencha o CPF", "Campo Obrigatório !", JOptionPane.WARNING_MESSAGE);
        	txtCPF.requestFocus();
        	return;
        }
        
        //Validando
        if(!Usuario.validar(cpf)) {
        	JOptionPane.showMessageDialog(this, "CPF Inválido!, Por Favor, Verifique. ", "CPF Inválido", JOptionPane.ERROR_MESSAGE);
        	txtCPF.requestFocus();
        	return;
        }
        
     // Validar CNH
        if (txtCNH.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, preencha o número da CNH.",  "Campo Obrigatório", JOptionPane.WARNING_MESSAGE);
            txtCNH.requestFocus();
            return;
        }
        
        //Verificando se o cpf já existe
        Motorista existente = sistema.getDadosMotoristas().buscar(cpf);
        if(existente != null) {
        	JOptionPane.showMessageDialog(this, "Ja existe um motorista com esse CPF!", "Esse Motorista já Existe", JOptionPane.ERROR_MESSAGE);
        	txtCPF.requestFocus();
        	return;
        }
        
        //Criando Motorista
        Motorista novoMotorista = new Motorista(txtNome.getText().trim(), cpf, txtNascimento.getText().trim(), txtEndereco.getText().trim(), txtCNH.getText().trim(), txtNomeSocial.getText().trim(), "Disponivel");
        
        //Salvando no arquivo
        sistema.getDadosMotoristas().cadastrar(novoMotorista);
        
        JOptionPane.showMessageDialog(this,
                "✅ Motorista cadastrado com sucesso!\n\n" +
                "Nome: " + novoMotorista.getNome() + "\n" +
                "CPF: " + novoMotorista.getCpf() + "\n" +
                "Status: " + novoMotorista.getStatus(),
                "Cadastro Realizado",
                JOptionPane.INFORMATION_MESSAGE);
        
        new TelaMotorista(novoMotorista).setVisible(true);
        dispose(); 
        
        
        
    }
    
    private void limparFormulario() {
        txtNome.setText("");
        txtCPF.setText("");
        txtNascimento.setText("");
        txtEndereco.setText("");
        txtCNH.setText("");
        txtNomeSocial.setText("");
        txtNome.requestFocus();
    }
}