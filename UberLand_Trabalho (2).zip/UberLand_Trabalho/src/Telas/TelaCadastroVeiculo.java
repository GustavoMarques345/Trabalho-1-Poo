package Telas;

import javax.swing.*;
import javax.swing.border.*;

import Classes.Motorista;
import Classes.SistemaUberLand;
import Classes.UberBlack;
import Classes.UberComfort;
import Classes.UberX;
import Classes.Veiculo;

import java.awt.*;
import java.awt.event.*;

public class TelaCadastroVeiculo extends JFrame {

    private static final long serialVersionUID = 1L;
    
    private final Color COR_PRIMARIA = new Color(241, 196, 15);    
    private final Color COR_SECUNDARIA = new Color(255, 220, 50);  
    private final Color COR_FUNDO = new Color(255, 250, 240);      
    private final Color COR_CARD = Color.WHITE;                    
    private final Color COR_TEXTO = new Color(60, 60, 60);         
    private final Color COR_BORDA = new Color(220, 220, 220);     
    
    // Campos do formulário
    private JTextField txtPlaca, txtChassi, txtCor, txtMarca, txtModelo, txtAno;
    private JComboBox<String> cbCategoria;
    
    private SistemaUberLand sistema = SistemaUberLand.getInstance();
    
    private Motorista motorista;
    
    public TelaCadastroVeiculo(Motorista m) {
    	this.motorista = m;
        setTitle("UberLand - Cadastro de Veículo");
        setSize(520, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Painel principal 
        JPanel fundo = new JPanel(new BorderLayout());
        fundo.setBackground(COR_FUNDO);
        setContentPane(fundo);
        
       
        JPanel card = new JPanel();
        card.setBackground(COR_CARD);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // Cabeçalho
        card.add(criarCabecalho());
        card.add(Box.createVerticalStrut(10));
        
        
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(230, 230, 230));
        sep.setMaximumSize(new Dimension(450, 1));
        card.add(sep);
        card.add(Box.createVerticalStrut(15));
        
        
        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setOpaque(false);
        painelForm.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // PLACA
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Placa:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtPlaca = criarTextField();
        painelForm.add(txtPlaca, gbc);
        
        // CHASSI
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Chassi:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtChassi = criarTextField();
        painelForm.add(txtChassi, gbc);
        
        // MARCA
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Marca:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtMarca = criarTextField();
        painelForm.add(txtMarca, gbc);
        
        // MODELO
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Modelo:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtModelo = criarTextField();
        painelForm.add(txtModelo, gbc);
        
        // ANO
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Ano:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtAno = criarTextField();
        txtAno.setText("2024");
        painelForm.add(txtAno, gbc);
        
        // COR
        gbc.gridx = 0; gbc.gridy = 5;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Cor:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtCor = criarTextField();
        painelForm.add(txtCor, gbc);
        
        // CATEGORIA 
        gbc.gridx = 0; gbc.gridy = 6;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Categoria:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        String[] categorias = {"Selecione...", "UberX", "UberComfort", "UberBlack"};
        cbCategoria = criarComboBox(categorias);
        painelForm.add(cbCategoria, gbc);
        
        card.add(painelForm);
        card.add(Box.createVerticalStrut(30));
        
        // Botões
        card.add(criarPainelBotoes());
        
        
        JScrollPane scrollPane = new JScrollPane(card);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        fundo.add(scrollPane, BorderLayout.CENTER);
    }
    
    private JPanel criarCabecalho() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Ícone
        JLabel lblIcone = new JLabel("🚘");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        lblIcone.setForeground(COR_PRIMARIA);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Título
        JLabel lblTitulo = new JLabel("Cadastro de Veículo");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(COR_TEXTO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Subtítulo
        JLabel lblSubtitulo = new JLabel("Informe os dados do veículo");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(120, 120, 120));
        lblSubtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblTitulo);
        cabecalho.add(Box.createVerticalStrut(2));
        cabecalho.add(lblSubtitulo);
        
        return cabecalho;
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        label.setForeground(COR_TEXTO);
        return label;
    }
    
    private JTextField criarTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        field.setPreferredSize(new Dimension(250, 35));
        field.setMaximumSize(new Dimension(250, 35));
        
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_SECUNDARIA, 2),
                    BorderFactory.createEmptyBorder(7, 9, 7, 9)
                ));
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_BORDA, 1),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
        });
        
        return field;
    }
    
    private JComboBox<String> criarComboBox(String[] itens) {
        JComboBox<String> combo = new JComboBox<>(itens);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        combo.setBackground(Color.WHITE);
        combo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        combo.setPreferredSize(new Dimension(250, 35));
        combo.setMaximumSize(new Dimension(250, 35));
        
        combo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                combo.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_SECUNDARIA, 2),
                    BorderFactory.createEmptyBorder(7, 9, 7, 9)
                ));
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                combo.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_BORDA, 1),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
        });
        
        return combo;
    }
    
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        painel.setOpaque(false);
        painel.setMaximumSize(new Dimension(400, 50));
        
        // Botão Cadastrar
        JButton btnCadastrar = criarBotao("💾 Cadastrar", COR_PRIMARIA);
        btnCadastrar.addActionListener(e -> cadastrarVeiculo());
        
        // Botão Limpar
        JButton btnLimpar = criarBotao("🗑️ Limpar", new Color(108, 117, 125));
        btnLimpar.addActionListener(e -> limparFormulario());
        
        // Botão Voltar
        JButton btnVoltar = criarBotao("← Voltar", new Color(150, 150, 150));
        btnVoltar.addActionListener(e -> {
            new TelaMotorista(motorista).setVisible(true); 
            dispose(); });
        
        painel.add(btnCadastrar);
        painel.add(btnLimpar);
        painel.add(btnVoltar);
        
        return painel;
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void cadastrarVeiculo() {
 
        if (motorista == null) {
            JOptionPane.showMessageDialog(this,
                "ERRO: Motorista não identificado!",
                "Erro",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
    	
    	
    	
        if (txtPlaca.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, preencha a placa do veículo.", 
                "Campo Obrigatório", 
                JOptionPane.WARNING_MESSAGE);
            txtPlaca.requestFocus();
            return;
        }
        
        if (txtMarca.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, preencha a marca do veículo.", 
                "Campo Obrigatório", 
                JOptionPane.WARNING_MESSAGE);
            txtMarca.requestFocus();
            return;
        }
        
        if (cbCategoria.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this,  "Por favor, selecione a categoria do veículo.", "Campo Obrigatório",  JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        //Verifica se já existe um veículo com essa placa
        String placa = txtPlaca.getText().trim();
        if (sistema.getDadosVeiculos().buscar(placa) != null) {
            JOptionPane.showMessageDialog(this,  "Já existe um veículo com esta placa!",  "Placa Existente",  JOptionPane.ERROR_MESSAGE);
            txtPlaca.requestFocus();
            return;
        }
        
       //Criando um veículo de acordo com a categoria
        Veiculo novoVeiculo = null;
        String categoria = (String) cbCategoria.getSelectedItem();
        
        if (categoria.equals("UberX")) {
            novoVeiculo = new UberX(placa,txtChassi.getText().trim(), txtCor.getText().trim(),  4, txtMarca.getText().trim(),true,"Disponivel",  true,  true);
        } else if (categoria.equals("UberComfort")) {
        	novoVeiculo = new UberComfort(placa, txtChassi.getText().trim(),txtCor.getText().trim(),4,txtMarca.getText().trim(),true,"Disponivel", true, true, true );
        }else if(categoria.equals("UberBlack")) {
        	 novoVeiculo = new UberBlack(placa, txtChassi.getText().trim(), txtCor.getText().trim(), 4, txtMarca.getText().trim(), true, "Disponivel", true, true, 3);
        }
        
        if(novoVeiculo != null) {
        	sistema.getDadosVeiculos().cadastrar(novoVeiculo);
        
        	//Associando o motorista com o veículo
        	motorista.addVeiculo(novoVeiculo);
        	
        	sistema.getDadosMotoristas().atualizar(motorista);
        	
        	JOptionPane.showMessageDialog(this, "✅ Veículo cadastrado com sucesso!\n\n" + "Placa: " + novoVeiculo.getPlaca() + "\n" +"Marca: " + novoVeiculo.getMarca() + "\n" +  "Categoria: " + categoria + "\n" +  "Motorista: " + motorista.getNome(),  "Cadastro Realizado",  JOptionPane.INFORMATION_MESSAGE);
                dispose(); 
        	
        }
        
        
    }
    
    private void limparFormulario() {
        txtPlaca.setText("");
        txtChassi.setText("");
        txtMarca.setText("");
        txtModelo.setText("");
        txtAno.setText("2026");
        txtCor.setText("");
        if (cbCategoria != null) {
            cbCategoria.setSelectedIndex(0);
        }
        txtPlaca.requestFocus();
    }
}