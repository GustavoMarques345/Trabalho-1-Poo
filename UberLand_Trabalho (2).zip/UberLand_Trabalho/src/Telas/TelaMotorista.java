package Telas;

import Classes.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TelaMotorista extends JFrame {
    
    private Motorista motorista;
    private SistemaUberLand sistema;
    
    private JTable tabelaDisponiveis, tabelaHistorico;
    private DefaultTableModel modeloDisponiveis, modeloHistorico;
    private JTextArea txtCorridaAtual;
    
    private JLabel lblCardStatus;
    private JLabel lblCardVeiculo;
    private JLabel lblCardMedia;
    
    public TelaMotorista(Motorista m) {
        this.motorista = m;
        this.sistema = SistemaUberLand.getInstance();
        
        setTitle("UberLand - Área do Motorista");
        setSize(800, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // ===== CABEÇALHO =====
        JPanel cabecalho = new JPanel();
        cabecalho.setBackground(new Color(155, 89, 182));
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel lblIcone = new JLabel("🚗");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 48));
        lblIcone.setForeground(Color.WHITE);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblNome = new JLabel(motorista.getNome());
        lblNome.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblNome.setForeground(Color.WHITE);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // CARDS COM REFERÊNCIAS 
        JPanel cards = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        cards.setOpaque(false);
        
        String placa = motorista.temVeiculo() ? motorista.getVeiculos().get(0).getPlaca() : "Nenhum";
        
        // Criar cards e guardar as referências dos LABELS
        JPanel cardStatus = criarInfoCard("Status", motorista.getStatus(), new Color(52, 152, 219));
        lblCardStatus = (JLabel) ((BorderLayout)cardStatus.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        
        JPanel cardVeiculo = criarInfoCard("Veículo", placa, new Color(241, 196, 15));
        lblCardVeiculo = (JLabel) ((BorderLayout)cardVeiculo.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        
        JPanel cardMedia = criarInfoCard("Média", String.format("%.1f ⭐", motorista.getMedia()), new Color(46, 204, 113));
        lblCardMedia = (JLabel) ((BorderLayout)cardMedia.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        
        cards.add(cardStatus);
        cards.add(cardVeiculo);
        cards.add(cardMedia);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblNome);
        cabecalho.add(Box.createVerticalStrut(15));
        cabecalho.add(cards);
        
        // Botão Cadastrar Veículo
        JButton btnCadastrarVeiculo = new JButton("➕ Cadastrar Novo Veículo");
        btnCadastrarVeiculo.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCadastrarVeiculo.setBackground(Color.WHITE);
        btnCadastrarVeiculo.setForeground(new Color(155, 89, 182));
        btnCadastrarVeiculo.setFocusPainted(false);
        btnCadastrarVeiculo.setBorderPainted(false);
        btnCadastrarVeiculo.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnCadastrarVeiculo.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCadastrarVeiculo.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        btnCadastrarVeiculo.addActionListener(e -> {
            new TelaCadastroVeiculo(motorista).setVisible(true);
        });
        
        cabecalho.add(Box.createVerticalStrut(10));
        cabecalho.add(btnCadastrarVeiculo);
        
        add(cabecalho, BorderLayout.NORTH);
        
        //  ABAS
        JTabbedPane abas = new JTabbedPane();
        abas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        abas.setBackground(Color.WHITE);
        
        abas.addTab("🚖 Corridas Disponíveis", criarPainelDisponiveis());
        abas.addTab("🔄 Corrida Atual", criarPainelAndamento());
        abas.addTab("📋 Histórico", criarPainelHistorico());
        abas.addTab("⚙️ Meu Status", criarPainelStatus());
        
        add(abas, BorderLayout.CENTER);
        
        //  RODAPÉ
        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rodape.setBackground(new Color(245, 245, 245));
        rodape.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JButton btnSair = new JButton("Sair da Conta");
        btnSair.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSair.setBackground(new Color(150, 150, 150));
        btnSair.setForeground(Color.WHITE);
        btnSair.setFocusPainted(false);
        btnSair.setBorderPainted(false);
        btnSair.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSair.addActionListener(e -> {
            new TelaMenu().setVisible(true);
            dispose();
        });
        
        rodape.add(btnSair);
        add(rodape, BorderLayout.SOUTH);
        
        atualizarStatus();
        carregarDisponiveis();
        carregarAndamento();
    }
    
    private JPanel criarInfoCard(String titulo, String valor, Color cor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblTitulo.setForeground(Color.GRAY);
        
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblValor.setForeground(cor);
        
        card.add(lblTitulo, BorderLayout.NORTH);
        card.add(lblValor, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel criarPainelDisponiveis() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titulo = new JLabel("🚖 CORRIDAS DISPONÍVEIS");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(new Color(155, 89, 182));
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        painel.add(titulo, BorderLayout.NORTH);
        
        String[] colunas = {"Cliente", "Origem", "Destino", "Data/Hora"};
        modeloDisponiveis = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabelaDisponiveis = new JTable(modeloDisponiveis);
        tabelaDisponiveis.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelaDisponiveis.setRowHeight(35);
        tabelaDisponiveis.setSelectionBackground(new Color(230, 240, 255));
        tabelaDisponiveis.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        
        JScrollPane scroll = new JScrollPane(tabelaDisponiveis);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        painel.add(scroll, BorderLayout.CENTER);
        
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        botoes.setOpaque(false);
        
        JButton btnAtualizar = new JButton("🔄 Atualizar");
        btnAtualizar.setBackground(new Color(52, 152, 219));
        btnAtualizar.setForeground(Color.WHITE);
        btnAtualizar.setFocusPainted(false);
        btnAtualizar.addActionListener(e -> carregarDisponiveis());
        
        JButton btnAceitar = new JButton("✅ Aceitar Corrida");
        btnAceitar.setBackground(new Color(46, 204, 113));
        btnAceitar.setForeground(Color.WHITE);
        btnAceitar.setFocusPainted(false);
        btnAceitar.addActionListener(e -> aceitarCorrida());
        
        botoes.add(btnAtualizar);
        botoes.add(btnAceitar);
        painel.add(botoes, BorderLayout.SOUTH);
        
        carregarDisponiveis();
        
        return painel;
    }
    
    private JPanel criarPainelAndamento() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titulo = new JLabel("🔄 CORRIDA EM ANDAMENTO");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(new Color(155, 89, 182));
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        painel.add(titulo, BorderLayout.NORTH);
        
        txtCorridaAtual = new JTextArea();
        txtCorridaAtual.setEditable(false);
        txtCorridaAtual.setFont(new Font("Monospaced", Font.PLAIN, 14));
        txtCorridaAtual.setBackground(new Color(250, 250, 250));
        txtCorridaAtual.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JScrollPane scroll = new JScrollPane(txtCorridaAtual);
        scroll.setPreferredSize(new Dimension(700, 200));
        painel.add(scroll, BorderLayout.CENTER);
        
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        botoes.setOpaque(false);
        
        JButton btnFinalizar = new JButton("🏁 FINALIZAR CORRIDA");
        btnFinalizar.setBackground(new Color(46, 204, 113));
        btnFinalizar.setForeground(Color.WHITE);
        btnFinalizar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnFinalizar.setFocusPainted(false);
        btnFinalizar.addActionListener(e -> finalizarCorrida());
        
        JButton btnCancelar = new JButton("❌ CANCELAR CORRIDA");
        btnCancelar.setBackground(new Color(231, 76, 60));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCancelar.setFocusPainted(false);
        btnCancelar.addActionListener(e -> cancelarCorrida());
        
        botoes.add(btnFinalizar);
        botoes.add(btnCancelar);
        painel.add(botoes, BorderLayout.SOUTH);
        
        return painel;
    }
    
    private JPanel criarPainelHistorico() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titulo = new JLabel("📋 HISTÓRICO DE CORRIDAS");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(new Color(155, 89, 182));
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        painel.add(titulo, BorderLayout.NORTH);
        
        String[] colunas = {"Cliente", "Origem", "Destino", "Data", "Ganho"};
        modeloHistorico = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabelaHistorico = new JTable(modeloHistorico);
        tabelaHistorico.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelaHistorico.setRowHeight(35);
        tabelaHistorico.setSelectionBackground(new Color(230, 240, 255));
        tabelaHistorico.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        
        JScrollPane scroll = new JScrollPane(tabelaHistorico);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        painel.add(scroll, BorderLayout.CENTER);
        
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        botoes.setOpaque(false);
        
        JButton btnAtualizar = new JButton("🔄 Atualizar Histórico");
        btnAtualizar.setBackground(new Color(52, 152, 219));
        btnAtualizar.setForeground(Color.WHITE);
        btnAtualizar.setFocusPainted(false);
        btnAtualizar.addActionListener(e -> carregarHistorico());
        
        botoes.add(btnAtualizar);
        painel.add(botoes, BorderLayout.SOUTH);
        
        carregarHistorico();
        
        return painel;
    }
    
    private JPanel criarPainelStatus() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel titulo = new JLabel("⚙️ GERENCIAR STATUS");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(new Color(155, 89, 182));
        painel.add(titulo, gbc);
        
        gbc.gridy = 1; gbc.gridwidth = 1;
        painel.add(new JLabel("Status atual:"), gbc);
        gbc.gridx = 1;
        JLabel lblStatusAtual = new JLabel(motorista.getStatus());
        lblStatusAtual.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblStatusAtual.setForeground(motorista.getStatus().equals("Disponivel") ? 
            new Color(46, 204, 113) : new Color(231, 76, 60));
        painel.add(lblStatusAtual, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        painel.add(new JLabel("Sua média:"), gbc);
        gbc.gridx = 1;
        painel.add(new JLabel(String.format("%.1f ⭐", motorista.getMedia())), gbc);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(220, 220, 220));
        painel.add(sep, gbc);
        
        gbc.gridy = 4;
        JLabel lblNovoStatus = new JLabel("Novo status:");
        lblNovoStatus.setFont(new Font("Segoe UI", Font.BOLD, 13));
        painel.add(lblNovoStatus, gbc);
        
        gbc.gridx = 1;
        String[] opcoes = {"Disponivel", "Nao disponivel"};
        JComboBox<String> cbStatus = new JComboBox<>(opcoes);
        cbStatus.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cbStatus.setBackground(Color.WHITE);
        cbStatus.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        painel.add(cbStatus, gbc);
        
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        JButton btnMudar = new JButton("ATUALIZAR STATUS");
        btnMudar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnMudar.setBackground(new Color(155, 89, 182));
        btnMudar.setForeground(Color.WHITE);
        btnMudar.setFocusPainted(false);
        btnMudar.setBorderPainted(false);
        btnMudar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnMudar.addActionListener(e -> {
            String novo = (String) cbStatus.getSelectedItem();
            if (novo.equals("Disponivel")) motorista.setStatus();
            else motorista.naoDisp();
            
            sistema.getDadosMotoristas().atualizar(motorista);
            atualizarStatus();
            lblStatusAtual.setText(motorista.getStatus());
            lblStatusAtual.setForeground(motorista.getStatus().equals("Disponivel") ? 
                new Color(46, 204, 113) : new Color(231, 76, 60));
            JOptionPane.showMessageDialog(this, "✅ Status atualizado para: " + novo);
        });
        painel.add(btnMudar, gbc);
        
        return painel;
    }
    
    private void carregarDisponiveis() {
        modeloDisponiveis.setRowCount(0);
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getStatus().equals("SOLICITADA")) {
                modeloDisponiveis.addRow(new Object[]{
                    c.getCliente().getNome(),
                    c.getOrigem(),
                    c.getDestino(),
                    c.getDataCorrida() + " " + c.getHoraCorrida()
                });
            }
        }
    }
    
    private void aceitarCorrida() {
        int linha = tabelaDisponiveis.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma corrida para aceitar!");
            return;
        }
        
        String clienteNome = (String) modeloDisponiveis.getValueAt(linha, 0);
        String origem = (String) modeloDisponiveis.getValueAt(linha, 1);
        
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getStatus().equals("SOLICITADA") && 
                c.getCliente().getNome().equals(clienteNome) &&
                c.getOrigem().equals(origem)) {
                
                if (!motorista.temVeiculo()) {
                    JOptionPane.showMessageDialog(this, 
                        "Você não possui veículo cadastrado!",
                        "Erro",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                Veiculo veiculoDoMotorista = motorista.getVeiculos().get(0);
                c.setVeiculo(veiculoDoMotorista);
                
                String horarioChegada = java.time.LocalTime.now().plusMinutes(5).toString().substring(0, 5);
                c.iniciarCorrida(motorista, horarioChegada);
                motorista.emViagem();
                
                sistema.getDadosCorridas().atualizar(c);
                sistema.getDadosMotoristas().atualizar(motorista);
                
                String mensagem = String.format(
                    "✅ Corrida aceita!\n\n" +
                    "🚗 Motorista: %s\n" +
                    "🚘 Veículo: %s %s (%s)\n" +
                    "💰 Tarifa: R$ %.2f/km\n" +
                    "⏱️ Previsão de chegada: %s",
                    motorista.getNome(),
                    veiculoDoMotorista.getMarca(),
                    veiculoDoMotorista.getCor(),
                    veiculoDoMotorista.getPlaca(),
                    obterTarifaPorKm(veiculoDoMotorista),
                    horarioChegada
                );
                
                JOptionPane.showMessageDialog(this, mensagem, "Sucesso", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                carregarDisponiveis();
                carregarAndamento();
                atualizarStatus();
                return;
            }
        }
    }

    private double obterTarifaPorKm(Veiculo v) {
        if (v instanceof UberX) return 2.50;
        if (v instanceof UberComfort) return 3.00;
        if (v instanceof UberBlack) return 5.37;
        return 0;
    }
    
    private void carregarAndamento() {
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getMotorista() != null && 
                c.getMotorista().getCpf().equals(motorista.getCpf()) &&
                c.getStatus().equals("EM ANDAMENTO")) {
                
                String texto = String.format(
                    "╔════════════════════════════════════╗\n" +
                    "║      🚖 CORRIDA EM ANDAMENTO       ║\n" +
                    "╚════════════════════════════════════╝\n\n" +
                    "👤 Cliente: %s\n" +
                    "📍 Origem: %s\n" +
                    "🏁 Destino: %s\n" +
                    "⏰ Início: %s\n",
                    c.getCliente().getNome(),
                    c.getOrigem(),
                    c.getDestino(),
                    c.getHoraCorrida()
                );
                
                txtCorridaAtual.setText(texto);
                return;
            }
        }
        txtCorridaAtual.setText(
            "╔════════════════════════════════════╗\n" +
            "║      🚖 NENHUMA CORRIDA ATIVA      ║\n" +
            "╚════════════════════════════════════╝\n\n" +
            "Aguardando nova corrida..."
        );
    }
    
    private void finalizarCorrida() {
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getMotorista() != null && 
                c.getMotorista().getCpf().equals(motorista.getCpf()) &&
                c.getStatus().equals("EM ANDAMENTO")) {
                
                String distStr = JOptionPane.showInputDialog(this, 
                    "Digite a distância percorrida (km):",
                    "Finalizar Corrida",
                    JOptionPane.QUESTION_MESSAGE);
                
                if (distStr == null) return;
                
                try {
                    double dist = Double.parseDouble(distStr.replace(",", "."));
                    if (dist <= 0) throw new NumberFormatException();
                    
                    String horarioFim = java.time.LocalTime.now().toString().substring(0, 5);
                    
                    c.finalizarCorrida(dist, 15, horarioFim);
                    motorista.setStatus();
                    
                    sistema.getDadosCorridas().atualizar(c);
                    sistema.getDadosMotoristas().atualizar(motorista);
                    
                    String financeiro = String.format(
                        "💰 DETALHES DA CORRIDA\n\n" +
                        "Distância: %.1f km\n" +
                        "Valor total: R$ %.2f\n" +
                        "Seu ganho: R$ %.2f\n" +
                        "UberLand: R$ %.2f",
                        c.getDistancia(),
                        c.getValorTotal(),
                        c.getValorMotorista(),
                        c.getValorUberLand()
                    );
                    
                    JOptionPane.showMessageDialog(this, financeiro, "Corrida Finalizada", 
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    if (!c.isMotoristaAvaliou()) {
                        avaliarCliente(c);
                        c.setMotoristaAvaliou(true);
                        sistema.getDadosCorridas().atualizar(c);
                    }
                    
                    carregarAndamento();
                    carregarHistorico();
                    atualizarStatus();
                    
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Distância inválida!");
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Nenhuma corrida em andamento!");
    }
    
    private void cancelarCorrida() {
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getMotorista() != null && 
                c.getMotorista().getCpf().equals(motorista.getCpf()) &&
                (c.getStatus().equals("EM ANDAMENTO") || c.getStatus().equals("SOLICITADA"))) {
                
                int confirm = JOptionPane.showConfirmDialog(this,
                    "Cancelar esta corrida?",
                    "Confirmar Cancelamento",
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    c.cancelaPorMotorista();
                    motorista.setStatus();
                    
                    sistema.getDadosMotoristas().atualizar(motorista);
                    sistema.getDadosCorridas().atualizar(c);
                    
                    JOptionPane.showMessageDialog(this, "✅ Corrida cancelada!");
                    carregarAndamento();
                    carregarDisponiveis();
                    atualizarStatus();
                }
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Nada para cancelar!");
    }
    
    private void avaliarCliente(Corrida c) {
        String[] opcoes = {"1 ⭐", "2 ⭐⭐", "3 ⭐⭐⭐", "4 ⭐⭐⭐⭐", "5 ⭐⭐⭐⭐⭐"};
        int escolha = JOptionPane.showOptionDialog(this,
            "Avalie o cliente " + c.getCliente().getNome(),
            "Avaliar Cliente",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            opcoes,
            opcoes[4]);
        
        if (escolha >= 0) {
            double nota = escolha + 1;
            c.getCliente().addAvaliacao(nota);
            sistema.getDadosUsuarios().atualizar(c.getCliente());
            
            JOptionPane.showMessageDialog(this, 
                "✅ Cliente avaliado com " + (int)nota + " estrelas!",
                "Avaliação Concluída",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void carregarHistorico() {
        modeloHistorico.setRowCount(0);
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getMotorista() != null && 
                c.getMotorista().getCpf().equals(motorista.getCpf()) &&
                c.getStatus().equals("FINALIZADA")) {
                
                modeloHistorico.addRow(new Object[]{
                    c.getCliente().getNome(),
                    c.getOrigem(),
                    c.getDestino(),
                    c.getDataCorrida(),
                    String.format("R$ %.2f", c.getValorMotorista())
                });
            }
        }
    }
    
    private void atualizarStatus() {
        if (lblCardStatus != null) {
            lblCardStatus.setText(motorista.getStatus());
            lblCardStatus.setForeground(motorista.getStatus().equals("Disponivel") ? 
                new Color(46, 204, 113) : new Color(231, 76, 60));
        }
        
        if (lblCardVeiculo != null) {
            String placa = motorista.temVeiculo() ? motorista.getVeiculos().get(0).getPlaca() : "Nenhum";
            lblCardVeiculo.setText(placa);
        }
        
        if (lblCardMedia != null) {
            lblCardMedia.setText(String.format("%.1f ⭐", motorista.getMedia()));
        }
    }
}