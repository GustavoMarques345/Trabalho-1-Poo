package Telas;

import Classes.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TelaBuscarRemoverCorrida extends JFrame {

    private static final long serialVersionUID = 1L;
    
    // Cores 
    private final Color COR_PRIMARIA = new Color(46, 204, 113);     
    private final Color COR_FUNDO = new Color(240, 250, 245);      
    private final Color COR_CARD = Color.WHITE;                    
    private final Color COR_TEXTO = new Color(60, 60, 60);         
    private final Color COR_BORDA = new Color(220, 220, 220);      
    private final Color COR_SUCESSO = new Color(46, 204, 113);     
    private final Color COR_INFO = new Color(52, 152, 219);        
    private final Color COR_AVISO = new Color(241, 196, 15);  
    
    // Componentes
    private JTable tabelaCorridas;
    private JTextField txtBusca;
    private JComboBox<String> cbTipoBusca;
    private DefaultTableModel modeloTabela;
    private JLabel lblTotalCorridas;
    
    // Sistema
    private SistemaUberLand sistema = SistemaUberLand.getInstance();
    
    public TelaBuscarRemoverCorrida() {
        setTitle("UberLand - Gerenciar Corridas");
        setSize(950, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Painel principal
        JPanel fundo = new JPanel(new BorderLayout());
        fundo.setBackground(COR_FUNDO);
        setContentPane(fundo);
        
    
        JPanel card = new JPanel();
        card.setBackground(COR_CARD);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // Cabeçalho
        card.add(criarCabecalho(), BorderLayout.NORTH);
        
        
        JPanel painelCentral = new JPanel(new BorderLayout(10, 10));
        painelCentral.setOpaque(false);
        painelCentral.add(criarPainelBusca(), BorderLayout.NORTH);
        painelCentral.add(criarPainelTabela(), BorderLayout.CENTER);
        
        card.add(painelCentral, BorderLayout.CENTER);
        
        fundo.add(card, BorderLayout.CENTER);
        
        // Carregar todas as corridas ao abrir
        carregarTodasCorridas();
    }
    
    private JPanel criarCabecalho() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setAlignmentX(Component.CENTER_ALIGNMENT);
        cabecalho.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JLabel lblIcone = new JLabel("🏁");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 48));
        lblIcone.setForeground(COR_PRIMARIA);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblTitulo = new JLabel("Gerenciar Corridas");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(COR_TEXTO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lblTotalCorridas = new JLabel("Carregando...");
        lblTotalCorridas.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTotalCorridas.setForeground(new Color(120, 120, 120));
        lblTotalCorridas.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblTitulo);
        cabecalho.add(Box.createVerticalStrut(2));
        cabecalho.add(lblTotalCorridas);
        
        return cabecalho;
    }
    
    private JPanel criarPainelBusca() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        painel.setOpaque(false);
        painel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        
        JLabel lblBusca = new JLabel("Buscar por:");
        lblBusca.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblBusca.setForeground(COR_TEXTO);
        
        String[] tipos = {"CPF do Cliente", "Data", "Status"};
        cbTipoBusca = new JComboBox<>(tipos);
        cbTipoBusca.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cbTipoBusca.setBackground(Color.WHITE);
        cbTipoBusca.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
        cbTipoBusca.setPreferredSize(new Dimension(150, 40));
        
        txtBusca = new JTextField(15);
        txtBusca.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusca.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        txtBusca.setPreferredSize(new Dimension(200, 40));
        txtBusca.addActionListener(e -> buscarCorridas());
        
        JButton btnBuscar = new JButton("🔍 Buscar");
        btnBuscar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setBackground(COR_INFO);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorderPainted(false);
        btnBuscar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBuscar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnBuscar.addActionListener(e -> buscarCorridas());
        
        JButton btnLimpar = new JButton("🗑️ Limpar");
        btnLimpar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnLimpar.setForeground(Color.WHITE);
        btnLimpar.setBackground(new Color(108, 117, 125));
        btnLimpar.setFocusPainted(false);
        btnLimpar.setBorderPainted(false);
        btnLimpar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLimpar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnLimpar.addActionListener(e -> {
            txtBusca.setText("");
            txtBusca.requestFocus();
            carregarTodasCorridas();
        });
        
        
        btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO);
            }
        });
        
        btnLimpar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125).darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125));
            }
        });
        
        painel.add(lblBusca);
        painel.add(cbTipoBusca);
        painel.add(txtBusca);
        painel.add(btnBuscar);
        painel.add(btnLimpar);
        
        return painel;
    }
    
    private JPanel criarPainelTabela() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setOpaque(false);
        
        // Modelo da tabela
        String[] colunas = {"ID", "Cliente", "Motorista", "Origem", "Destino", 
                           "Data", "Hora", "Status", "Valor (R$)"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Criar tabela
        tabelaCorridas = new JTable(modeloTabela);
        tabelaCorridas.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabelaCorridas.setRowHeight(35);
        tabelaCorridas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabelaCorridas.setShowGrid(true);
        tabelaCorridas.setGridColor(new Color(230, 230, 230));
        tabelaCorridas.setSelectionBackground(new Color(230, 240, 255));
        
        // Cabeçalho da tabela
        JTableHeader header = tabelaCorridas.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(new Color(240, 240, 240));
        header.setForeground(COR_TEXTO);
        header.setReorderingAllowed(false);
        
        // Centralizar colunas
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        for (int i = 0; i < colunas.length; i++) {
            if (i != 1 && i != 2 && i != 3 && i != 4) {
                tabelaCorridas.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }
        
        // Renderizador especial para status (cores)
        tabelaCorridas.getColumnModel().getColumn(7).setCellRenderer(new StatusCellRenderer());
        
        // Larguras das colunas
        tabelaCorridas.getColumnModel().getColumn(0).setPreferredWidth(40);   // ID
        tabelaCorridas.getColumnModel().getColumn(1).setPreferredWidth(120);  // Cliente
        tabelaCorridas.getColumnModel().getColumn(2).setPreferredWidth(120);  // Motorista
        tabelaCorridas.getColumnModel().getColumn(3).setPreferredWidth(120);  // Origem
        tabelaCorridas.getColumnModel().getColumn(4).setPreferredWidth(120);  // Destino
        tabelaCorridas.getColumnModel().getColumn(5).setPreferredWidth(80);   // Data
        tabelaCorridas.getColumnModel().getColumn(6).setPreferredWidth(60);   // Hora
        tabelaCorridas.getColumnModel().getColumn(7).setPreferredWidth(120);  // Status
        tabelaCorridas.getColumnModel().getColumn(8).setPreferredWidth(80);   // Valor
        
        JScrollPane scrollPane = new JScrollPane(tabelaCorridas);
        scrollPane.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
        scrollPane.setPreferredSize(new Dimension(880, 350));
        
        painel.add(scrollPane, BorderLayout.CENTER);
        
        // Painel de botões de ação
        JPanel painelAcoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        painelAcoes.setOpaque(false);
        painelAcoes.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            " Ações ",
            TitledBorder.CENTER,
            TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            COR_TEXTO
        ));
        
        JButton btnVisualizar = criarBotaoAcao("👁️ Visualizar Detalhes", COR_INFO, 180);
        btnVisualizar.addActionListener(e -> visualizarCorrida());
        
        JButton btnRemover = criarBotaoAcao("🗑️ Remover Corrida", COR_PRIMARIA, 180);
        btnRemover.addActionListener(e -> removerCorrida());
        
        JButton btnAtualizar = criarBotaoAcao("🔄 Atualizar Lista", COR_SUCESSO, 180);
        btnAtualizar.addActionListener(e -> carregarTodasCorridas());
        
        JButton btnVoltar = criarBotaoAcao("← Voltar ao Menu", new Color(150, 150, 150), 180);
        btnVoltar.addActionListener(e -> dispose());
        
        painelAcoes.add(btnVisualizar);
        painelAcoes.add(btnRemover);
        painelAcoes.add(btnAtualizar);
        painelAcoes.add(btnVoltar);
        
        painel.add(painelAcoes, BorderLayout.SOUTH);
        
        return painel;
    }
    
    private JButton criarBotaoAcao(String texto, Color cor, int largura) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        botao.setPreferredSize(new Dimension(largura, 40));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
 //Renderizador para mudar os status
    private class StatusCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            Component c = super.getTableCellRendererComponent(table, value, 
                isSelected, hasFocus, row, column);
            
            if (!isSelected) {
                String status = value != null ? value.toString() : "";
                
                if (status.contains("FINALIZADA")) {
                    setBackground(new Color(212, 237, 218)); 
                    setForeground(new Color(21, 87, 36));    
                } else if (status.contains("EM ANDAMENTO")) {
                    setBackground(new Color(255, 243, 205)); 
                    setForeground(new Color(133, 100, 4));  
                } else if (status.contains("SOLICITADA")) {
                    setBackground(new Color(207, 226, 255)); 
                    setForeground(new Color(12, 84, 160));   
                } else if (status.contains("CANCELADA")) {
                    setBackground(new Color(248, 215, 218)); 
                    setForeground(new Color(114, 28, 36));   
                } else {
                    setBackground(Color.WHITE);
                    setForeground(Color.BLACK);
                }
            }
            
            setHorizontalAlignment(JLabel.CENTER);
            return c;
        }
    }
    
    //Buscar corridas
    	private void buscarCorridas() {
    	    String termo = txtBusca.getText().trim();
    	    int tipo = cbTipoBusca.getSelectedIndex();
    	    
    	    if (termo.isEmpty()) {
    	        JOptionPane.showMessageDialog(this,
    	            "Digite algo para buscar.",
    	            "Campo Vazio",
    	            JOptionPane.WARNING_MESSAGE);
    	        return;
    	    }
    	    
    	    limparTabela();
    	    
    	    ArrayList<Corrida> todas = sistema.getDadosCorridas().listar();
    	    ArrayList<Corrida> resultados = new ArrayList<>();
    	    
    	    switch (tipo) {
    	        case 0: // CPF do Cliente
    	            String cpfLimpo = termo.replaceAll("[^0-9]", "");
    	            for (Corrida c : todas) {
    	                if (c.getCliente() != null) {
    	                    String cpfCliente = c.getCliente().getCpf().replaceAll("[^0-9]", "");
    	                    if (cpfCliente.equals(cpfLimpo)) {
    	                        resultados.add(c);
    	                    }
    	                }
    	            }
    	            break;
    	            
    	        case 1: // Data
    	            for (Corrida c : todas) {
    	                if (c.getDataCorrida() != null && 
    	                    c.getDataCorrida().contains(termo)) {
    	                    resultados.add(c);
    	                }
    	            }
    	            break;
    	            
    	        case 2: // Status
    	            for (Corrida c : todas) {
    	                if (c.getStatus() != null && 
    	                    c.getStatus().toUpperCase().contains(termo.toUpperCase())) {
    	                    resultados.add(c);
    	                }
    	            }
    	            break;
    	    }
    	    
    	    if (resultados.isEmpty()) {
    	        JOptionPane.showMessageDialog(this,
    	            "Nenhuma corrida encontrada com: '" + termo + "'",
    	            "Busca sem resultados",
    	            JOptionPane.INFORMATION_MESSAGE);
    	        carregarTodasCorridas();
    	    } else {
    	        int id = 1;
    	        for (Corrida c : resultados) {
    	            adicionarCorridaNaTabela(c, id++);
    	        }
    	        lblTotalCorridas.setText("Encontradas " + resultados.size() + " corrida(s)");
    	    }
    	}
   
    	//Carregar Corridas
    private void carregarTodasCorridas() {
        limparTabela();
        
        ArrayList<Corrida> corridas = sistema.getDadosCorridas().listar();
        
        int id = 1;
        for (Corrida c : corridas) {
            adicionarCorridaNaTabela(c, id++);
        }
        
        lblTotalCorridas.setText("Total de corridas registradas: " + corridas.size());
    }
    
    //Adicionar corrida na tela
    private void adicionarCorridaNaTabela(Corrida c, int id) {
        String nomeCliente = c.getCliente() != null ? c.getCliente().getNome() : "N/A";
        String nomeMotorista = c.getMotorista() != null ? c.getMotorista().getNome() : "N/A";
        
        Object[] linha = {
            id,
            nomeCliente,
            nomeMotorista,
            c.getOrigem(),
            c.getDestino(),
            c.getDataCorrida() != null ? c.getDataCorrida() : "N/I",
            c.getHoraCorrida() != null ? c.getHoraCorrida() : "N/I",
            c.getStatus(),
            String.format("%.2f", c.getValorTotal())
        };
        modeloTabela.addRow(linha);
    }
    
    //Vizualizar detalhes das corridas
    private void visualizarCorrida() {
        int linha = tabelaCorridas.getSelectedRow();
        
        if (linha == -1) {
            JOptionPane.showMessageDialog(this,
                "Selecione uma corrida na tabela.",
                "Nenhum selecionado",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Pega os dados da linha para identificar a corrida
        String clienteNome = (String) modeloTabela.getValueAt(linha, 1);
        String data = (String) modeloTabela.getValueAt(linha, 5);
        String hora = (String) modeloTabela.getValueAt(linha, 6);
        
        // Busca a corrida correspondente
        Corrida corrida = null;
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getCliente() != null && c.getCliente().getNome().equals(clienteNome) &&
                c.getDataCorrida().equals(data) && c.getHoraCorrida().equals(hora)) {
                corrida = c;
                break;
            }
        }
        
        if (corrida == null) {
            JOptionPane.showMessageDialog(this,
                "Erro ao encontrar a corrida.",
                "Erro",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Formatar valores
        String valorTotal = String.format("%.2f", corrida.getValorTotal());
        String valorUberLand = String.format("%.2f", corrida.getValorUberLand());
        String valorMotorista = String.format("%.2f", corrida.getValorMotorista());
        String valorExtra = String.format("%.2f", corrida.getValorExtra());
        
        String mensagem = String.format(
            "<html><body style='width: 400px; padding: 15px; font-family: Segoe UI;'>" +
            "<h3 style='color: #27ae60; border-bottom: 2px solid #27ae60; padding-bottom: 8px;'>" +
            "🏁 DETALHES DA CORRIDA</h3>" +
            
            "<table style='width: 100%; border-collapse: collapse; font-size: 13px;'>" +
            
            "<tr><td colspan='2' style='padding: 8px; background: #27ae6020; font-weight: bold;'>👥 ENVOLVIDOS</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa; width: 40%;'><b>Cliente:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Motorista:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 8px; background: #27ae6020; font-weight: bold; margin-top: 10px;'>📍 TRAJETO</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Origem:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Destino:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 8px; background: #27ae6020; font-weight: bold;'>⏱️ HORÁRIOS</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Solicitação:</b></td>" +
            "<td style='padding: 5px;'>%s às %s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Chegada motorista:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Finalização:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Duração:</b></td>" +
            "<td style='padding: 5px;'>%.1f min</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 8px; background: #27ae6020; font-weight: bold;'>💰 VALORES</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Distância:</b></td>" +
            "<td style='padding: 5px;'>%.1f km</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Valor total:</b></td>" +
            "<td style='padding: 5px;'>R$ %s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Valor extra:</b></td>" +
            "<td style='padding: 5px;'>R$ %s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>UberLand (60%%):</b></td>" +
            "<td style='padding: 5px;'>R$ %s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Motorista (40%%):</b></td>" +
            "<td style='padding: 5px;'>R$ %s</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 8px; background: #27ae6020; font-weight: bold;'>📊 STATUS</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Status:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            "<tr><td style='padding: 5px; background: #f8f9fa;'><b>Pagamento:</b></td>" +
            "<td style='padding: 5px;'>%s</td></tr>" +
            
            "</table></body></html>",
            
            
            corrida.getCliente() != null ? corrida.getCliente().getNome() : "N/A",
            corrida.getMotorista() != null ? corrida.getMotorista().getNome() : "N/A",
            
            // Trajeto
            corrida.getOrigem(),
            corrida.getDestino(),
            
            // Horários
            corrida.getDataCorrida(),
            corrida.getHoraCorrida(),
            corrida.getHorarioChegada() != null ? corrida.getHorarioChegada() : "N/A",
            corrida.getHorarioFinal() != null ? corrida.getHorarioFinal() : "N/A",
            corrida.getDuracaoViagem(),
            
            // Valores
            corrida.getDistancia(),
            valorTotal,
            valorExtra,
            valorUberLand,
            valorMotorista,
            
            // Status
            corrida.getStatus(),
            corrida.getFormaPagamento() != null ? corrida.getFormaPagamento() : "N/I"
        );
        
        JOptionPane.showMessageDialog(this, 
            mensagem, 
            "Detalhes da Corrida", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    //Remover Corrida
    private void removerCorrida() {
        int linha = tabelaCorridas.getSelectedRow();
        
        if (linha == -1) {
            JOptionPane.showMessageDialog(this,
                "Selecione uma corrida na tabela para remover.",
                "Nenhum selecionado",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String cliente = (String) modeloTabela.getValueAt(linha, 1);
        String data = (String) modeloTabela.getValueAt(linha, 5);
        String status = (String) modeloTabela.getValueAt(linha, 7);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><body style='width: 350px; padding: 10px;'>" +
            "<h3 style='color: #27ae60;'>⚠️ CONFIRMAR REMOÇÃO</h3>" +
            "<p>Tem certeza que deseja remover esta corrida?</p>" +
            "<p><b>Cliente:</b> " + cliente + "<br>" +
            "<b>Data:</b> " + data + "<br>" +
            "<b>Status:</b> " + status + "</p>" +
            "<p><font color='red'><b>Esta ação não pode ser desfeita!</b></font></p>" +
            "</body></html>",
            "Confirmar Remoção",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            
            ArrayList<Corrida> todas = sistema.getDadosCorridas().listar();
            for (int i = 0; i < todas.size(); i++) {
                Corrida c = todas.get(i);
                if (c.getCliente() != null && c.getCliente().getNome().equals(cliente) &&
                    c.getDataCorrida().equals(data)) {
                    
                    todas.remove(i);
                    
                    try {
                        java.lang.reflect.Field field = DadosCorrida.class.getDeclaredField("corridas");
                        field.setAccessible(true);
                        field.set(sistema.getDadosCorridas(), todas);
                        Persist.gravar(todas, "corridas.dat");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    
                    JOptionPane.showMessageDialog(this,
                        "✅ Corrida removida com sucesso!",
                        "Remoção Concluída",
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    carregarTodasCorridas();
                    return;
                }
            }
            
            JOptionPane.showMessageDialog(this,
                "❌ Erro ao remover corrida!",
                "Erro",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void limparTabela() {
        modeloTabela.setRowCount(0);
    }
}