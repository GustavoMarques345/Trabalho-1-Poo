package Telas;

import Classes.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TelaCliente extends JFrame {
    
    private Cliente cliente;
    private SistemaUberLand sistema;
    
    // Componentes
    private JLabel lblCorridas, lblMedia, lblDesconto;
    private JTextArea areaHistorico;
    private JTextField txtOrigem, txtDestino;
    private JTable tabelaAndamento;
    private DefaultTableModel modeloAndamento;
    private JComboBox<String> cbCategoria;
    
    private boolean perguntou = false;
    
    public TelaCliente(Cliente c) {
        this.cliente = c;
        this.sistema = SistemaUberLand.getInstance();
        this.perguntou = false;
        
        setTitle("UberLand - Área do Cliente");
        setSize(750, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // CABEÇALHO MODERNO
        JPanel cabecalho = new JPanel();
        cabecalho.setBackground(new Color(0, 90, 180));
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel lblIcone = new JLabel("👤");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 48));
        lblIcone.setForeground(Color.WHITE);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblNome = new JLabel(cliente.getNome());
        lblNome.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblNome.setForeground(Color.WHITE);
        lblNome.setAlignmentX(Component.CENTER_ALIGNMENT);
        
     // Cabeçalho para status VIP
        JLabel lblStatusVip = new JLabel(cliente.isVip() ? "⭐ VIP" : "");
        lblStatusVip.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblStatusVip.setForeground(new Color(241, 196, 15));
        lblStatusVip.setAlignmentX(Component.CENTER_ALIGNMENT);

        cabecalho.add(lblStatusVip);
        
        // Cards de informação
        JPanel cards = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        cards.setOpaque(false);
        
        cards.add(criarInfoCard("Corridas", String.valueOf(cliente.getNroCorrida()), new Color(52, 152, 219)));
        cards.add(criarInfoCard("Média", String.format("%.1f ⭐", cliente.getMedia()), new Color(241, 196, 15)));
        
        double desconto = cliente.calcularDesconto() * 100;
        cards.add(criarInfoCard("Desconto", (int)desconto + "%", new Color(46, 204, 113)));
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblNome);
        cabecalho.add(Box.createVerticalStrut(15));
        cabecalho.add(cards);
        
        add(cabecalho, BorderLayout.NORTH);
        
        //  ABAS 
        JTabbedPane abas = new JTabbedPane();
        abas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        abas.setBackground(Color.WHITE);
        
        abas.addTab("🚖 Solicitar Corrida", criarPainelSolicitar());
        abas.addTab("🔄 Em Andamento", criarPainelAndamento());
        abas.addTab("📋 Histórico", criarPainelHistorico());
        abas.addTab("⭐ Status VIP", criarPainelVIP());
        
        add(abas, BorderLayout.CENTER);
        
        //  RODAPÉ 
        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rodape.setBackground(new Color(245, 245, 245));
        rodape.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JButton btnSair = new JButton("Sair da Conta");
        btnSair.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnSair.setBackground(new Color(150, 150, 150));
        btnSair.setForeground(Color.WHITE);
        btnSair.setFocusPainted(false);
        btnSair.setBorderPainted(false);
        btnSair.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSair.addActionListener(e -> {
            new TelaMenu().setVisible(true);
            dispose();
        });
        
        rodape.add(btnSair);
        add(rodape, BorderLayout.SOUTH);
    }
    
    private JPanel criarInfoCard(String titulo, String valor, Color cor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        
        JLabel lblTitulo = new JLabel(titulo);
        lblTitulo.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblTitulo.setForeground(Color.GRAY);
        
        JLabel lblValor = new JLabel(valor);
        lblValor.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblValor.setForeground(cor);
        
        card.add(lblTitulo, BorderLayout.NORTH);
        card.add(lblValor, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel criarPainelSolicitar() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Título da seção
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel titulo = new JLabel("📋 DADOS DA VIAGEM");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(new Color(0, 90, 180));
        painel.add(titulo, gbc);
        
        gbc.gridwidth = 1;
        
        // Origem
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel lblOrigem = new JLabel("📍 Origem:");
        lblOrigem.setFont(new Font("Segoe UI", Font.BOLD, 13));
        painel.add(lblOrigem, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtOrigem = new JTextField(20);
        txtOrigem.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtOrigem.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        painel.add(txtOrigem, gbc);
        
        // Destino
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        JLabel lblDestino = new JLabel("🏁 Destino:");
        lblDestino.setFont(new Font("Segoe UI", Font.BOLD, 13));
        painel.add(lblDestino, gbc);
        
        gbc.gridx = 1; gbc.weightx = 1.0;
        txtDestino = new JTextField(20);
        txtDestino.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtDestino.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        painel.add(txtDestino, gbc);
        
        // Categoria
        gbc.gridx = 0; gbc.gridy = 3;
        JLabel lblCategoria = new JLabel("🚘 Categoria:");
        lblCategoria.setFont(new Font("Segoe UI", Font.BOLD, 13));
        painel.add(lblCategoria, gbc);
        
        gbc.gridx = 1;
        String[] categorias = {
            "UberX - Econômico (R$ 2,50/km)",
            "UberComfort - Conforto (R$ 3,00/km)",
            "UberBlack - Premium (R$ 5,37/km)"
        };
        cbCategoria = new JComboBox<>(categorias);
        cbCategoria.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cbCategoria.setBackground(Color.WHITE);
        cbCategoria.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        painel.add(cbCategoria, gbc);
        
        // Separador
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(220, 220, 220));
        painel.add(sep, gbc);
        
        // Informação de desconto
        gbc.gridy = 5;
        double desconto = cliente.calcularDesconto() * 100;
        JLabel lblDescontoInfo = new JLabel(
            "<html><b>Seu desconto atual:</b> " + (int)desconto + "%</html>",
            SwingConstants.CENTER
        );
        lblDescontoInfo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDescontoInfo.setForeground(new Color(46, 204, 113));
        painel.add(lblDescontoInfo, gbc);
        
        // Botão Solicitar
        gbc.gridy = 6;
        JButton btnSolicitar = new JButton("🚖 SOLICITAR CORRIDA");
        btnSolicitar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSolicitar.setBackground(new Color(46, 204, 113));
        btnSolicitar.setForeground(Color.WHITE);
        btnSolicitar.setFocusPainted(false);
        btnSolicitar.setBorderPainted(false);
        btnSolicitar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSolicitar.setPreferredSize(new Dimension(250, 45));
        btnSolicitar.addActionListener(e -> solicitarCorrida());
        painel.add(btnSolicitar, gbc);
        
        return painel;
    }
    
    private JPanel criarPainelAndamento() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Título
        JLabel titulo = new JLabel("🔄 CORRIDAS EM ANDAMENTO");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(new Color(0, 90, 180));
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        painel.add(titulo, BorderLayout.NORTH);
        
        // Tabela
        String[] colunas = {"Motorista", "Origem", "Destino", "Status"};
        modeloAndamento = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabelaAndamento = new JTable(modeloAndamento);
        tabelaAndamento.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelaAndamento.setRowHeight(35);
        tabelaAndamento.setSelectionBackground(new Color(230, 240, 255));
        tabelaAndamento.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        
        JScrollPane scroll = new JScrollPane(tabelaAndamento);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        painel.add(scroll, BorderLayout.CENTER);
        
        // Botões
        JPanel botoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        botoes.setOpaque(false);
        
        JButton btnAtualizar = new JButton("🔄 Atualizar");
        btnAtualizar.setBackground(new Color(52, 152, 219));
        btnAtualizar.setForeground(Color.WHITE);
        btnAtualizar.setFocusPainted(false);
        btnAtualizar.addActionListener(e -> carregarCorridasAndamento());
        
        JButton btnCancelar = new JButton("❌ Cancelar Selecionada");
        btnCancelar.setBackground(new Color(231, 76, 60));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFocusPainted(false);
        btnCancelar.addActionListener(e -> cancelarCorrida());
        
        botoes.add(btnAtualizar);
        botoes.add(btnCancelar);
        
        painel.add(botoes, BorderLayout.SOUTH);
        
        carregarCorridasAndamento();
        
        return painel;
    }
    
    private JPanel criarPainelHistorico() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Título
        JLabel titulo = new JLabel("📋 HISTÓRICO DE CORRIDAS");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titulo.setForeground(new Color(0, 90, 180));
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        painel.add(titulo, BorderLayout.NORTH);
        
        // Área de texto
        areaHistorico = new JTextArea();
        areaHistorico.setEditable(false);
        areaHistorico.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaHistorico.setBackground(new Color(250, 250, 250));
        
        JScrollPane scroll = new JScrollPane(areaHistorico);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
        painel.add(scroll, BorderLayout.CENTER);
        
        // Botão Atualizar
        JButton btnAtualizar = new JButton("🔄 Atualizar Histórico");
        btnAtualizar.setBackground(new Color(52, 152, 219));
        btnAtualizar.setForeground(Color.WHITE);
        btnAtualizar.setFocusPainted(false);
        btnAtualizar.addActionListener(e -> carregarHistorico());
        
        JPanel rodape = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rodape.setOpaque(false);
        rodape.add(btnAtualizar);
        
        painel.add(rodape, BorderLayout.SOUTH);
        
        return painel;
    }
    
    private JPanel criarPainelVIP() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        int corridas = cliente.getNroCorrida();
        double desconto = cliente.calcularDesconto() * 100;
        
        // Título
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel titulo = new JLabel("⭐ PROGRAMA DE FIDELIDADE VIP");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titulo.setForeground(new Color(0, 90, 180));
        painel.add(titulo, gbc);
        
        // Barra de progresso
        gbc.gridy = 1;
        JProgressBar progresso = new JProgressBar(0, 20);
        progresso.setValue(corridas);
        progresso.setStringPainted(true);
        progresso.setString(corridas + " corridas");
        progresso.setForeground(new Color(241, 196, 15));
        progresso.setFont(new Font("Segoe UI", Font.BOLD, 12));
        painel.add(progresso, gbc);
        
        // Informações
        gbc.gridy = 2; gbc.gridwidth = 1;
        painel.add(new JLabel("Corridas atuais:"), gbc);
        gbc.gridx = 1;
        painel.add(new JLabel(String.valueOf(corridas)), gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        painel.add(new JLabel("Desconto atual:"), gbc);
        gbc.gridx = 1;
        painel.add(new JLabel((int)desconto + "%"), gbc);
        
        gbc.gridx = 0; gbc.gridy = 4;
        painel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1;
        String status = cliente.isVip()? "VIP ⭐" : "Cliente Comum";
        painel.add(new JLabel(status), gbc);
        
        // Próxima meta
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        if (corridas < 5) {
            int faltam = 5 - corridas;
            painel.add(new JLabel("Faltam " + faltam + " corridas para ser VIP (5% de desconto)!"), gbc);
        } else if (corridas < 10) {
            int faltam = 10 - corridas;
            painel.add(new JLabel("Faltam " + faltam + " corridas para 10% de desconto!"), gbc);
        } else if (corridas < 15) {
            int faltam = 15 - corridas;
            painel.add(new JLabel("Faltam " + faltam + " corridas para 15% de desconto!"), gbc);
        } else if (corridas < 20) {
            int faltam = 20 - corridas;
            painel.add(new JLabel("Faltam " + faltam + " corridas para 20% de desconto!"), gbc);
        } else {
            painel.add(new JLabel("Parabéns! Você tem o desconto máximo de 20%!"), gbc);
        }
        return painel;
    }
    
    private void solicitarCorrida() {
        //  VALIDAÇÕES 
        if (txtOrigem.getText().trim().isEmpty() || txtDestino.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Preencha origem e destino!", 
                "Campos Obrigatórios", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        //  PEGA A CATEGORIA ESCOLHIDA 
        String categoriaSelecionada = (String) cbCategoria.getSelectedItem();
        String tipoVeiculo = categoriaSelecionada.split(" ")[0]; // "UberX", "UberComfort" ou "UberBlack"
        
        //  VERIFICA SE EXISTE MOTORISTA DISPONÍVEl
        // independente da categoria - depois o motorista escolhe
        boolean temMotoristaDisponivel = false;
        for (Motorista m : sistema.getDadosMotoristas().listar()) {
            if (m.getStatus().equals("Disponivel") && m.temVeiculo()) {
                temMotoristaDisponivel = true;
                break;
            }
        }
        
        if (!temMotoristaDisponivel) {
            JOptionPane.showMessageDialog(this, 
                "Nenhum motorista disponível no momento!", 
                "Indisponível", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        //  CRIA A CORRIDA SEM MOTORISTA E SEM VEÍCULO 
        // A corrida fica com status "SOLICITADA" aguardando motorista
        Corrida corrida = new Corrida(
            cliente,                     // Cliente que solicitou
            null,                        // Veículo null (será definido pelo motorista)
            txtOrigem.getText().trim(),   // Origem
            txtDestino.getText().trim(),  // Destino
            java.time.LocalDate.now().toString(),           // Data atual
            java.time.LocalTime.now().toString().substring(0, 5) // Hora atual
        );
        
        //  SALVA NO SISTEMA (status = "SOLICITADA")
        sistema.getDadosCorridas().cadastrar(corrida);
        
        // MENSAGEM DE SUCESSO
        String mensagem = String.format(
            "✅ CORRIDA SOLICITADA COM SUCESSO!\n\n" +
            "🚘 Categoria: %s\n" +
            "⏱️ Status: Aguardando motorista aceitar...\n\n" +
            "📍 Origem: %s\n" +
            "🏁 Destino: %s",
            tipoVeiculo,
            txtOrigem.getText(),
            txtDestino.getText()
        );
        
        JOptionPane.showMessageDialog(this, mensagem, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
        
        // LIMPA CAMPOS E ATUALIZA TELA
        txtOrigem.setText("");
        txtDestino.setText("");
        carregarCorridasAndamento(); // Atualiza a aba "Em Andamento"
        perguntou = false; // Reseta controle de avaliação
    }
    
    private void carregarCorridasAndamento() {
        modeloAndamento.setRowCount(0);
        
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getCliente() != null && 
                c.getCliente().getCpf().equals(cliente.getCpf()) &&
                (c.getStatus().equals("SOLICITADA") || c.getStatus().equals("EM ANDAMENTO"))) {
                
                Object[] linha = {
                    c.getMotorista() != null ? c.getMotorista().getNome() : "Aguardando...",
                    c.getOrigem(),
                    c.getDestino(),
                    c.getStatus()
                };
                modeloAndamento.addRow(linha);
            }
        }
    }
    
    private void cancelarCorrida() {
        int linha = tabelaAndamento.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma corrida para cancelar!");
            return;
        }
        
        String origem = (String) modeloAndamento.getValueAt(linha, 1);
        String destino = (String) modeloAndamento.getValueAt(linha, 2);
        String status = (String) modeloAndamento.getValueAt(linha, 3);
        
        for (Corrida c : sistema.getDadosCorridas().listar()) {
            if (c.getCliente() != null && 
                c.getCliente().getCpf().equals(cliente.getCpf()) &&
                c.getOrigem().equals(origem) && 
                c.getDestino().equals(destino)) {
                
                String mensagem = status.equals("SOLICITADA") ?
                    "Cancelar esta corrida? (Sem taxa)" : 
                    "Cancelar esta corrida? (Taxa de R$ 2,50 será cobrada!)";
                
                int confirm = JOptionPane.showConfirmDialog(this, mensagem, 
                    "Confirmar Cancelamento", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    
                    if (status.equals("SOLICITADA")) {
                        c.cancelaPorCliente();
                    } else {
                        c.cancelarPorClienteDuranteViagem();
                    }
                    
                    if (c.getMotorista() != null) {
                        c.getMotorista().setStatus();
                        sistema.getDadosMotoristas().atualizar(c.getMotorista());
                    }
                    
                    sistema.getDadosCorridas().atualizar(c);
                    
                    JOptionPane.showMessageDialog(this, "✅ Corrida cancelada com sucesso!");
                    carregarCorridasAndamento();
                    carregarHistorico();
                }
                return;
            }
        }
    }
    
    private void carregarHistorico() {
        ArrayList<Corrida> corridas = sistema.getDadosCorridas().buscarCliente(cliente.getCpf());
        
        if (corridas.isEmpty()) {
            areaHistorico.setText("📭 Nenhuma corrida realizada até o momento.");
            return;
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("═══════════════════════════════════════════════\n");
        sb.append("            📋 HISTÓRICO DE CORRIDAS          \n");
        sb.append("═══════════════════════════════════════════════\n\n");
        
        int i = 1;
        double totalGasto = 0;
        
        // Verifica se tem corrida não avaliada
        boolean temNaoAvaliada = false;
        for (Corrida c : corridas) {
            if (c.getStatus().equals("FINALIZADA") && 
                c.getMotorista() != null && 
                !c.isClienteAvaliou()) {
                temNaoAvaliada = true;
                break;
            }
        }
        
        // Se tem não avaliada e ainda não perguntou
        if (temNaoAvaliada && !perguntou) {
            for (Corrida c : corridas) {
                if (c.getStatus().equals("FINALIZADA") && 
                    c.getMotorista() != null && 
                    !c.isClienteAvaliou()) {
                    
                    int resp = JOptionPane.showConfirmDialog(this,
                        "A corrida com " + c.getMotorista().getNome() + " foi finalizada!\n" +
                        "Deseja avaliar o motorista?",
                        "Avaliar Motorista", 
                        JOptionPane.YES_NO_OPTION);
                    
                    if (resp == JOptionPane.YES_OPTION) {
                        avaliarMotorista(c);
                        c.setClienteAvaliou(true);
                        sistema.getDadosCorridas().atualizar(c);
                    }
                    perguntou = true;
                    break;
                }
            }
        }
        
        // Construir histórico
        for (Corrida c : corridas) {
            String data = c.getDataCorrida() != null ? c.getDataCorrida() : "N/I";
            String hora = c.getHoraCorrida() != null ? c.getHoraCorrida() : "N/I";
            String nomeMotorista = c.getMotorista() != null ? c.getMotorista().getNome() : "N/A";
            double valor = c.getValorTotal();
            totalGasto += valor;
            
            sb.append("───── CORRIDA #").append(i++).append(" ─────\n");
            sb.append("📅 Data: ").append(data).append(" às ").append(hora).append("\n");
            sb.append("📍 ").append(c.getOrigem()).append(" → ").append(c.getDestino()).append("\n");
            sb.append("🚗 Motorista: ").append(nomeMotorista).append("\n");
            
            if (c.getMotorista() != null) {
                sb.append("⭐ Nota do motorista: ").append(String.format("%.1f", c.getMotorista().getMedia())).append("\n");
            }
            
            sb.append("📊 Status: ").append(c.getStatus()).append("\n");
            sb.append("💰 Valor: R$ ").append(String.format("%.2f", valor)).append("\n");
            
            if (cliente.isVip() && c.getStatus().equals("FINALIZADA")) { //Mostrar se o desconto VIP é aplicável
                double descontoAplicado = cliente.calcularDesconto() * 100;
                double valorSemDesconto = c.getValorTotal() / (1 - cliente.calcularDesconto());
                double descontoPercentual = cliente.calcularDesconto() * 100;
                sb.append("🎁 Desconto VIP aplicado: ").append((int)descontoAplicado).append("%\n");
                
                sb.append(" Valor Original: R$ ").append(String.format("%.2f", valorSemDesconto)).append(")\n");
               
                
                }
            
            sb.append("───────────────────────────────\n\n");
        }
        
        sb.append("═══════════════════════════════════════════════\n");
        sb.append("📊 RESUMO:\n");
        sb.append("   • Total de corridas: ").append(corridas.size()).append("\n");
        sb.append("   • Total gasto: R$ ").append(String.format("%.2f", totalGasto)).append("\n");
        sb.append("   • Média por corrida: R$ ").append(String.format("%.2f", totalGasto / corridas.size())).append("\n");
        sb.append("═══════════════════════════════════════════════\n");
        
        areaHistorico.setText(sb.toString());
        areaHistorico.setCaretPosition(0);
    }
    
    private void avaliarMotorista(Corrida corrida) {
        String[] opcoes = {
            "⭐ 1 Estrela", 
            "⭐⭐ 2 Estrelas", 
            "⭐⭐⭐ 3 Estrelas", 
            "⭐⭐⭐⭐ 4 Estrelas", 
            "⭐⭐⭐⭐⭐ 5 Estrelas"
        };
        
        int escolha = JOptionPane.showOptionDialog(this,
            "<html><body style='width: 300px; text-align: center;'>" +
            "<h3>Avalie o motorista</h3>" +
            "<p><b>" + corrida.getMotorista().getNome() + "</b></p>" +
            "<p>Como foi a experiência com este motorista?</p>" +
            "</body></html>",
            "Avaliar Motorista",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            opcoes,
            opcoes[4]);
        
        if (escolha >= 0) {
            double nota = escolha + 1;
            Motorista motorista = corrida.getMotorista();
            motorista.addAvaliacao(nota);
            sistema.getDadosMotoristas().atualizar(motorista);
            
            JOptionPane.showMessageDialog(this, 
                "✅ Motorista avaliado com " + (int)nota + " estrelas!\n\n" +
                "Nova média do motorista: " + String.format("%.1f", motorista.getMedia()) + " ⭐",
                "Avaliação Concluída",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
}