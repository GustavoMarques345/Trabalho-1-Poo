package Telas;

import Classes.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TelaBuscarRemoverMotorista extends JFrame {

    private static final long serialVersionUID = 1L;
    
    // Cores
    private final Color COR_PRIMARIA = new Color(155, 89, 182);     
    private final Color COR_FUNDO = new Color(245, 240, 250);      
    private final Color COR_CARD = Color.WHITE;                    
    private final Color COR_TEXTO = new Color(60, 60, 60);         
    private final Color COR_BORDA = new Color(220, 220, 220);      
    private final Color COR_SUCESSO = new Color(46, 204, 113);     
    private final Color COR_INFO = new Color(52, 152, 219);        
    
    // Componentes
    private JTable tabelaMotoristas;
    private JTextField txtBusca;
    private DefaultTableModel modeloTabela;
    private JLabel lblTotalMotoristas;
    
    // Sistema
    private SistemaUberLand sistema = SistemaUberLand.getInstance();
    
    public TelaBuscarRemoverMotorista() {
        setTitle("UberLand - Gerenciar Motoristas");
        setSize(850, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Painel principal
        JPanel fundo = new JPanel(new BorderLayout());
        fundo.setBackground(COR_FUNDO);
        setContentPane(fundo);
        
        // Card principal
        JPanel card = new JPanel();
        card.setBackground(COR_CARD);
        card.setLayout(new BorderLayout(10, 10));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // Cabeçalho
        card.add(criarCabecalho(), BorderLayout.NORTH);
        
        // Painel central
        JPanel painelCentral = new JPanel(new BorderLayout(10, 10));
        painelCentral.setOpaque(false);
        painelCentral.add(criarPainelBusca(), BorderLayout.NORTH);
        painelCentral.add(criarPainelTabela(), BorderLayout.CENTER);
        
        card.add(painelCentral, BorderLayout.CENTER);
        
        fundo.add(card, BorderLayout.CENTER);
        
        // Carregar todos os motoristas ao abrir
        carregarTodosMotoristas();
    }
    
    private JPanel criarCabecalho() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setAlignmentX(Component.CENTER_ALIGNMENT);
        cabecalho.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JLabel lblIcone = new JLabel("🚗");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 48));
        lblIcone.setForeground(COR_PRIMARIA);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel lblTitulo = new JLabel("Gerenciar Motoristas");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(COR_TEXTO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lblTotalMotoristas = new JLabel("Carregando...");
        lblTotalMotoristas.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTotalMotoristas.setForeground(new Color(120, 120, 120));
        lblTotalMotoristas.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblTitulo);
        cabecalho.add(Box.createVerticalStrut(2));
        cabecalho.add(lblTotalMotoristas);
        
        return cabecalho;
    }
    
    private JPanel criarPainelBusca() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        painel.setOpaque(false);
        painel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        
        JLabel lblBusca = new JLabel("Buscar por CPF:");
        lblBusca.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblBusca.setForeground(COR_TEXTO);
        
        txtBusca = new JTextField(15);
        txtBusca.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBusca.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        txtBusca.setPreferredSize(new Dimension(200, 40));
        txtBusca.addActionListener(e -> buscarMotoristaPorCPF());
        
        JButton btnBuscar = new JButton("🔍 Buscar");
        btnBuscar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setBackground(COR_INFO);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setBorderPainted(false);
        btnBuscar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBuscar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnBuscar.addActionListener(e -> buscarMotoristaPorCPF());
        
        JButton btnLimpar = new JButton("🗑️ Limpar");
        btnLimpar.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        btnLimpar.setForeground(Color.WHITE);
        btnLimpar.setBackground(new Color(108, 117, 125));
        btnLimpar.setFocusPainted(false);
        btnLimpar.setBorderPainted(false);
        btnLimpar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLimpar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        btnLimpar.addActionListener(e -> {
            txtBusca.setText("");
            txtBusca.requestFocus();
            carregarTodosMotoristas();
        });
        
        
        btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnBuscar.setBackground(COR_INFO);
            }
        });
        
        btnLimpar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125).darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btnLimpar.setBackground(new Color(108, 117, 125));
            }
        });
        
        painel.add(lblBusca);
        painel.add(txtBusca);
        painel.add(btnBuscar);
        painel.add(btnLimpar);
        
        return painel;
    }
    
    private JPanel criarPainelTabela() {
        JPanel painel = new JPanel(new BorderLayout());
        painel.setOpaque(false);
        
        // Modelo da tabela
        String[] colunas = {"ID", "Nome", "CPF", "CNH", "Nome Social", "Status", "Veículo"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Criar tabela
        tabelaMotoristas = new JTable(modeloTabela);
        tabelaMotoristas.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabelaMotoristas.setRowHeight(35);
        tabelaMotoristas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabelaMotoristas.setShowGrid(true);
        tabelaMotoristas.setGridColor(new Color(230, 230, 230));
        tabelaMotoristas.setSelectionBackground(new Color(230, 240, 255));
        
        // Cabeçalho da tabela
        JTableHeader header = tabelaMotoristas.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(240, 240, 240));
        header.setForeground(COR_TEXTO);
        header.setReorderingAllowed(false);
        
        // Centralizar colunas
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        tabelaMotoristas.getColumnModel().getColumn(0).setCellRenderer(centerRenderer); // ID
        tabelaMotoristas.getColumnModel().getColumn(2).setCellRenderer(centerRenderer); // CPF
        tabelaMotoristas.getColumnModel().getColumn(3).setCellRenderer(centerRenderer); // CNH
        tabelaMotoristas.getColumnModel().getColumn(5).setCellRenderer(centerRenderer); // Status
        tabelaMotoristas.getColumnModel().getColumn(6).setCellRenderer(centerRenderer); // Veículo
        
        // Larguras das colunas
        tabelaMotoristas.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabelaMotoristas.getColumnModel().getColumn(1).setPreferredWidth(180);
        tabelaMotoristas.getColumnModel().getColumn(2).setPreferredWidth(120);
        tabelaMotoristas.getColumnModel().getColumn(3).setPreferredWidth(100);
        tabelaMotoristas.getColumnModel().getColumn(4).setPreferredWidth(120);
        tabelaMotoristas.getColumnModel().getColumn(5).setPreferredWidth(100);
        tabelaMotoristas.getColumnModel().getColumn(6).setPreferredWidth(100);
        
        JScrollPane scrollPane = new JScrollPane(tabelaMotoristas);
        scrollPane.setBorder(BorderFactory.createLineBorder(COR_BORDA, 1));
        scrollPane.setPreferredSize(new Dimension(780, 300));
        
        painel.add(scrollPane, BorderLayout.CENTER);
        
        // Painel de botões de ação
        JPanel painelAcoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        painelAcoes.setOpaque(false);
        painelAcoes.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            " Ações ",
            TitledBorder.CENTER,
            TitledBorder.TOP,
            new Font("Segoe UI", Font.BOLD, 14),
            COR_TEXTO
        ));
        
        JButton btnRemover = criarBotaoAcao("🗑️ Remover Motorista", COR_PRIMARIA, 180);
        btnRemover.addActionListener(e -> removerMotorista());
        
        JButton btnAtualizar = criarBotaoAcao("🔄 Atualizar Lista", COR_SUCESSO, 180);
        btnAtualizar.addActionListener(e -> carregarTodosMotoristas());
        
        JButton btnVoltar = criarBotaoAcao("← Voltar ao Menu", new Color(150, 150, 150), 180);
        btnVoltar.addActionListener(e -> dispose());
        
        painelAcoes.add(btnRemover);
        painelAcoes.add(btnAtualizar);
        painelAcoes.add(btnVoltar);
        
        painel.add(painelAcoes, BorderLayout.SOUTH);
        
        return painel;
    }
    
    private JButton criarBotaoAcao(String texto, Color cor, int largura) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        botao.setPreferredSize(new Dimension(largura, 40));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private String formatarCPF(String cpf) {
        if (cpf == null || cpf.length() != 11) return cpf;
        return cpf.substring(0, 3) + "." + cpf.substring(3, 6) + "." + 
               cpf.substring(6, 9) + "-" + cpf.substring(9, 11);
    }
    
    private void buscarMotoristaPorCPF() {
        String cpfDigitado = txtBusca.getText().trim();
        
        if (cpfDigitado.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Digite o CPF do motorista.",
                "Campo Vazio",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String cpfLimpo = cpfDigitado.replaceAll("[^0-9]", "");
        
        if (cpfLimpo.length() != 11) {
            JOptionPane.showMessageDialog(this,
                "CPF deve ter 11 dígitos.",
                "CPF Inválido",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Motorista motorista = sistema.getDadosMotoristas().buscar(cpfLimpo);
        
        if (motorista != null) {
            mostrarDetalhesMotorista(motorista);
        } else {
            JOptionPane.showMessageDialog(this,
                "Nenhum motorista encontrado com o CPF: " + formatarCPF(cpfLimpo),
                "Não encontrado",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
 
    private void mostrarDetalhesMotorista(Motorista m) {
        String cpfFormatado = formatarCPF(m.getCpf());
        
        // CORRIGIDO: Verifica se tem veículo e pega o primeiro
        String placaVeiculo = "Nenhum";
        String modeloVeiculo = "-";
        
        if (m.temVeiculo()) {
            placaVeiculo = m.getVeiculos().get(0).getPlaca();
            modeloVeiculo = m.getVeiculos().get(0).getMarca();
        }
        
        String mediaStr = String.format("%.1f", m.getMedia());
        
        // CONCATENAÇÃO SIMPLES - SEM String.format()
        String mensagem = "<html><body style='width: 350px; padding: 10px; font-family: Segoe UI;'>" +
            "<h3 style='color: #8e44ad; border-bottom: 2px solid #8e44ad; padding-bottom: 5px;'>" +
            "🚗 DADOS DO MOTORISTA</h3>" +
            
            "<table style='width: 100%; border-collapse: collapse; font-size: 12px;'>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Nome:</b></td>" +
            "<td style='padding: 4px;'>" + m.getNome() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Nome Social:</b></td>" +
            "<td style='padding: 4px;'>" + m.getNome_Social() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>CPF:</b></td>" +
            "<td style='padding: 4px;'>" + cpfFormatado + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>CNH:</b></td>" +
            "<td style='padding: 4px;'>" + m.getCnh() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Endereço:</b></td>" +
            "<td style='padding: 4px;'>" + m.getEndereco() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Nascimento:</b></td>" +
            "<td style='padding: 4px;'>" + (m.getDatanasc() != null ? m.getDatanasc() : "-") + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Status:</b></td>" +
            "<td style='padding: 4px;'>" + m.getStatus() + "</td></tr>" +
            
            "<tr><td colspan='2' style='padding: 8px; background: #8e44ad20; border-top: 1px solid #8e44ad; " +
            "border-bottom: 1px solid #8e44ad; text-align: center; font-weight: bold;'>🚘 VEÍCULO</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Placa:</b></td>" +
            "<td style='padding: 4px;'>" + placaVeiculo + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Modelo:</b></td>" +
            "<td style='padding: 4px;'>" + modeloVeiculo + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Corridas:</b></td>" +
            "<td style='padding: 4px;'>" + m.getNroCorrida() + "</td></tr>" +
            
            "<tr><td style='padding: 4px; background: #f8f9fa;'><b>Avaliação:</b></td>" +
            "<td style='padding: 4px;'>" + mediaStr + " ⭐</td></tr>" +
            
            "</table></body></html>";
        
        JOptionPane.showMessageDialog(this, 
            mensagem, 
            "Detalhes: " + m.getNome(), 
            JOptionPane.INFORMATION_MESSAGE);
    }

    private void carregarTodosMotoristas() {
        limparTabela();
        
        ArrayList<Motorista> motoristas = sistema.getDadosMotoristas().listar();
        
        int id = 1;
        for (Motorista m : motoristas) {
            String cpfFormatado = formatarCPF(m.getCpf());
            
            // Pega a placa do primeiro veículo se existir
            String placa = "---";
            if (m.temVeiculo()) {
                placa = m.getVeiculos().get(0).getPlaca();
            }
            
            Object[] linha = {
                id++,
                m.getNome(),
                cpfFormatado,
                m.getCnh(),
                m.getNome_Social(),
                m.getStatus(),
                placa
            };
            modeloTabela.addRow(linha);
        }
        
        lblTotalMotoristas.setText("Total de motoristas cadastrados: " + motoristas.size());
    }
    
    //Remove Motorista
    private void removerMotorista() {
        int linha = tabelaMotoristas.getSelectedRow();
        
        if (linha == -1) {
            JOptionPane.showMessageDialog(this,
                "Selecione um motorista na tabela para remover.",
                "Nenhum selecionado",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String nome = (String) modeloTabela.getValueAt(linha, 1);
        String cpfLinha = (String) modeloTabela.getValueAt(linha, 2);
        String cpfBusca = cpfLinha.replaceAll("[^0-9]", "");
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "<html><body style='width: 350px; padding: 10px;'>" +
            "<h3 style='color: #8e44ad;'>⚠️ CONFIRMAR REMOÇÃO</h3>" +
            "<p>Tem certeza que deseja remover o motorista?</p>" +
            "<p><b>Nome:</b> " + nome + "<br>" +
            "<b>CPF:</b> " + cpfLinha + "</p>" +
            "<p><font color='red'><b>Esta ação não pode ser desfeita!</b></font></p>" +
            "</body></html>",
            "Confirmar Remoção",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            boolean removeu = sistema.getDadosMotoristas().excluir(cpfBusca);
            
            if (removeu) {
                JOptionPane.showMessageDialog(this,
                    "✅ Motorista removido com sucesso!",
                    "Remoção Concluída",
                    JOptionPane.INFORMATION_MESSAGE);
                
                carregarTodosMotoristas();
            } else {
                JOptionPane.showMessageDialog(this,
                    "❌ Erro ao remover motorista!",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void limparTabela() {
        modeloTabela.setRowCount(0);
    }
}