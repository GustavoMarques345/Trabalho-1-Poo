package Telas;

import javax.swing.*;
import javax.swing.border.*;

import Classes.Cliente;
import Classes.SistemaUberLand;

import java.awt.*;
import java.awt.event.*;

public class TelaCadastroCliente extends JFrame {

    private static final long serialVersionUID = 1L;
    
    
    private final Color COR_PRIMARIA = new Color(0, 90, 180);
    private final Color COR_SECUNDARIA = new Color(0, 140, 255);
    private final Color COR_FUNDO = new Color(240, 245, 250);
    private final Color COR_CARD = Color.WHITE;
    private final Color COR_TEXTO = new Color(60, 60, 60);
    private final Color COR_BORDA = new Color(220, 220, 220);
    
    
    private JTextField txtNome, txtCPF, txtNascimento, txtEmail, txtCelular;
    private JComboBox<String> cbGenero, cbPagamento;
    private SistemaUberLand sistema = SistemaUberLand.getInstance(); // Referencia ao sistema
    
    public TelaCadastroCliente() {
        setTitle("UberLand - Cadastro de Cliente");
        setSize(520, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        
        // Painel principal 
        JPanel fundo = new JPanel(new BorderLayout());
        fundo.setBackground(COR_FUNDO);
        setContentPane(fundo);
        
        // Card principal
        JPanel card = new JPanel();
        card.setBackground(COR_CARD);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        // Cabeçalho
        card.add(criarCabecalho());
        card.add(Box.createVerticalStrut(10));
        
        
        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(230, 230, 230));
        sep.setMaximumSize(new Dimension(450, 1));
        card.add(sep);
        card.add(Box.createVerticalStrut(15));
        
        // Painel do formulário com GridBag
        JPanel painelForm = new JPanel(new GridBagLayout());
        painelForm.setOpaque(false);
        painelForm.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // NOME
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Nome:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtNome = criarTextField();
        painelForm.add(txtNome, gbc);
        
        // CPF
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("CPF:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtCPF = criarTextField();
        painelForm.add(txtCPF, gbc);
        
        // DATA NASCIMENTO
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Data Nasc.:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtNascimento = criarTextField();
        painelForm.add(txtNascimento, gbc);
        
        // EMAIL
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("E-mail:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtEmail = criarTextField();
        painelForm.add(txtEmail, gbc);
        
        // CELULAR
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Celular:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        txtCelular = criarTextField();
        painelForm.add(txtCelular, gbc);
        
        // GÊNERO 
        gbc.gridx = 0; gbc.gridy = 5;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Gênero:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        String[] generos = {"Selecione...", "Masculino", "Feminino", "Prefiro não informar"};
        cbGenero = criarComboBox(generos);
        painelForm.add(cbGenero, gbc);
        
        // FORMA PAGAMENTO
        gbc.gridx = 0; gbc.gridy = 6;
        gbc.weightx = 0.3;
        gbc.anchor = GridBagConstraints.EAST;
        painelForm.add(criarLabel("Pagamento:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 0.7;
        gbc.anchor = GridBagConstraints.WEST;
        String[] pagamentos = {"Selecione...", "Cartão de Crédito", "Cartão de Débito", "PIX", "Dinheiro"};
        cbPagamento = criarComboBox(pagamentos);
        painelForm.add(cbPagamento, gbc);
        
        card.add(painelForm);
        card.add(Box.createVerticalStrut(15));
        
        
        card.add(criarPainelBotoes());
        
       
        JScrollPane scrollPane = new JScrollPane(card);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        fundo.add(scrollPane, BorderLayout.CENTER);
    }
    
    private JPanel criarCabecalho() {
        JPanel cabecalho = new JPanel();
        cabecalho.setLayout(new BoxLayout(cabecalho, BoxLayout.Y_AXIS));
        cabecalho.setOpaque(false);
        cabecalho.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Ícone
        JLabel lblIcone = new JLabel("👤");
        lblIcone.setFont(new Font("Segoe UI", Font.PLAIN, 40));
        lblIcone.setForeground(COR_PRIMARIA);
        lblIcone.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Título
        JLabel lblTitulo = new JLabel("Cadastro de Cliente");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(COR_TEXTO);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Subtítulo
        JLabel lblSubtitulo = new JLabel("Preencha os dados do cliente");
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitulo.setForeground(new Color(120, 120, 120));
        lblSubtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        cabecalho.add(lblIcone);
        cabecalho.add(Box.createVerticalStrut(5));
        cabecalho.add(lblTitulo);
        cabecalho.add(Box.createVerticalStrut(2));
        cabecalho.add(lblSubtitulo);
        
        return cabecalho;
    }
    
    private JLabel criarLabel(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        label.setForeground(COR_TEXTO);
        return label;
    }
    
    private JTextField criarTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        field.setPreferredSize(new Dimension(250, 35));
        field.setMaximumSize(new Dimension(250, 35));
        
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_SECUNDARIA, 2),
                    BorderFactory.createEmptyBorder(7, 9, 7, 9)
                ));
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_BORDA, 1),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
        });
        
        return field;
    }
    
    private JComboBox<String> criarComboBox(String[] itens) {
        JComboBox<String> combo = new JComboBox<>(itens);
        combo.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        combo.setBackground(Color.WHITE);
        combo.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COR_BORDA, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        combo.setPreferredSize(new Dimension(250, 35));
        combo.setMaximumSize(new Dimension(250, 35));
        
        combo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                combo.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_SECUNDARIA, 2),
                    BorderFactory.createEmptyBorder(7, 9, 7, 9)
                ));
            }
            
            @Override
            public void focusLost(FocusEvent e) {
                combo.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COR_BORDA, 1),
                    BorderFactory.createEmptyBorder(8, 10, 8, 10)
                ));
            }
        });
        
        return combo;
    }
    
    private JPanel criarPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        painel.setOpaque(false);
        painel.setMaximumSize(new Dimension(400, 50));
        
        // Botão Cadastrar
        JButton btnCadastrar = criarBotao("💾 Cadastrar", COR_PRIMARIA);
        btnCadastrar.addActionListener(e -> cadastrarCliente());
        
        // Botão Limpar
        JButton btnLimpar = criarBotao("🗑️ Limpar", new Color(108, 117, 125));
        btnLimpar.addActionListener(e -> limparFormulario());
        
        // Botão Voltar
        JButton btnVoltar = criarBotao("← Voltar", new Color(150, 150, 150));
        btnVoltar.addActionListener(e -> dispose());
        
        painel.add(btnCadastrar);
        painel.add(btnLimpar);
        painel.add(btnVoltar);
        
        return painel;
    }
    
    private JButton criarBotao(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
        botao.setForeground(Color.WHITE);
        botao.setBackground(cor);
        botao.setFocusPainted(false);
        botao.setBorderPainted(false);
        botao.setCursor(new Cursor(Cursor.HAND_CURSOR));
        botao.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        
        botao.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                botao.setBackground(cor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                botao.setBackground(cor);
            }
        });
        
        return botao;
    }
    
    private void cadastrarCliente() {
        if (txtNome.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor, preencha o nome do cliente.", 
                "Campo Obrigatório", 
                JOptionPane.WARNING_MESSAGE);
            txtNome.requestFocus();
            return;
        }
        
        //Validar o CPF
        String cpf =  txtCPF.getText().trim();
        	if(cpf.isEmpty()) {
        		JOptionPane.showMessageDialog(this, "Por favor, preencha o CPF. ", "Campo Obrigatório", JOptionPane.WARNING_MESSAGE);
        		txtCPF.requestFocus();
        		return;
        }
        
        	//Verificando se o cpf já existe
        	Cliente existente = sistema.getDadosUsuarios().buscar(cpf);
        	if (existente != null) {
        		JOptionPane.showMessageDialog(this, "Ja existe um cliente cadastrado com esse CPF!", "CPF já Existente", JOptionPane.ERROR_MESSAGE);
        		txtCPF.requestFocus();
        		return;
        	}
        	
        	//Criando novo cliente
        	Cliente novoCliente = new Cliente (txtNome.getText().trim(), cpf, txtNascimento.getText().trim(), txtEmail.getText().trim(), txtCelular.getText().trim(), cbGenero.getSelectedItem().toString(), cbPagamento.getSelectedItem().toString());
        	
        	sistema.getDadosUsuarios().cadastrar(novoCliente); //Salvando o cliente no arquivo
        	
        	JOptionPane.showMessageDialog(this, 
        	        "✅ Cliente cadastrado com sucesso!\n\n" +
        	        "Nome: " + novoCliente.getNome() + "\n" +
        	        "CPF: " + novoCliente.getCpf(),
        	        "Cadastro Realizado",
        	        JOptionPane.INFORMATION_MESSAGE); // Cliente Cadastrado
        	
        	new TelaCliente(novoCliente).setVisible(true); 
        	
        	dispose();
        	
    }
    
    private void limparFormulario() {
        txtNome.setText("");
        txtCPF.setText("");
        txtNascimento.setText("");
        txtEmail.setText("");
        txtCelular.setText("");
        cbGenero.setSelectedIndex(0);
        cbPagamento.setSelectedIndex(0);
        txtNome.requestFocus();
    }
}